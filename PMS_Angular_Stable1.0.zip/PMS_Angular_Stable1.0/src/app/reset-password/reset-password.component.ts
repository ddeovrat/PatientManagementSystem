import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../shared/auth.service';
import { PatientLoginRegisterService } from '../shared/patient-login-register.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css',
  '../../assets/css/bootstrap.min.css',
  '../../assets/css/font-awesome.min.css',
  '../../assets/css/style.css'
  ]
})
export class ResetPasswordComponent implements OnInit {

  constructor(private _auth:AuthService) { }

  ResetPassForm: FormGroup = new FormGroup({
    Email: new FormControl("",[Validators.required]),
    OldPassword: new FormControl("", [Validators.required,Validators.pattern("^[a-zA-Z0-9]{8,}$")]),
    Password: new FormControl("", [Validators.required,Validators.pattern("^[a-zA-Z0-9]{8,}$")]),
    ConPassword: new FormControl("",[Validators.required,Validators.pattern("^[a-zA-Z0-9]{8,}$")])
  },
  // { validators: [match] }
    );

  ngOnInit(): void {
  }

  Resetsubmit_click(form:FormGroup){
    this._auth.resetPassword(form.value.Email,form.value.OldPassword,form.value.Password);
    }

  }
