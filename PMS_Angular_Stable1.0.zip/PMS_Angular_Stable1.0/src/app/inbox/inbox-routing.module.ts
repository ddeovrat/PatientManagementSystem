import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoleGuard } from '../shared/role.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UpcomingAppointmentsComponent } from './upcoming-appointments/upcoming-appointments.component';

const routes: Routes = [

  {path:'',redirectTo:'dashboard',pathMatch:'full'},

{path:'dashboard', component:DashboardComponent,canActivate:[RoleGuard]}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InboxRoutingModule { }
