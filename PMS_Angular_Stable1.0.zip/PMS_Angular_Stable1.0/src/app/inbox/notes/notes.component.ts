import { JsonPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { InboxService } from 'src/app/shared/inbox.service';


@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.css']
})
export class NotesComponent implements OnInit {

  receiverarray:any;
  receiverdesignation:Number=0;
  receiverdesignationstring:any;
  saveurgency:string="urgent";
  sentnoteslist:any;
  receivednoteslist:any;
  roleId:any;
  responseId:any=0;
  msgTime:any;
 

  constructor(private  _inboxService:InboxService,private _toastr:ToastrService) { }

  ngOnInit(): void {
    this.ComposeNoteForm.patchValue({ Urgency:'Not Urgent'})
  }

  ComposeNoteForm: FormGroup = new FormGroup({ 
    Receiver:new FormControl("",[Validators.required]),
    Designation:new FormControl("",[Validators.required]),
    Urgency:new FormControl("",[Validators.required]),
    Message:new FormControl("",Validators.required),
    ResponseAgainst:new FormControl()
  },
    );

  sendNote(data:FormGroup)
  {
    this._inboxService.sendNote(data).subscribe(data=>{
      if(data!=0)
      this._toastr.success("Note has been sent"); 
     } );
     this.ComposeNoteForm.reset();
  }

  onChange(id:any)
  {
    this._inboxService.getDesignation(Number(id.target.value)).subscribe(desig=>
      
      {    if(desig==2)
        this.receiverdesignationstring="Physician";
        else
        this.receiverdesignationstring="Nurse";
      });
  }

  getHospitalUsers()
  {
    this._inboxService.getHospitalUsers().subscribe(data=>{
      this.receiverarray=data;
      console.log(data);
      //this.msgTime=data.values.
     } );
  }

  getSentNotes()
  {
    this._inboxService.getSentNotes(Number(sessionStorage.getItem("id"))).subscribe(data=>{
      this.sentnoteslist=data; 
     } );
  }

  getReceivedNotes()
  { 
    this._inboxService.getReceivedNotes(Number(sessionStorage.getItem("id"))).subscribe(data=>{
      this.receivednoteslist=data;
     } );
  }

  sendReply(messageId:any,senderId:any)
  {
    this._inboxService.getHospitalUser(messageId,senderId).subscribe(data=>{
     this.receiverarray=data;
      this.responseId=messageId;
    });  
  }
  populatedropdown()
  {
    this.getHospitalUsers();
  }

  reset()
  {
    this.ComposeNoteForm.reset();
  }
 
}
