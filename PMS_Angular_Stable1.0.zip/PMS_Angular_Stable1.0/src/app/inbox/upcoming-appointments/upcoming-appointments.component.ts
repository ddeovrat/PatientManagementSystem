import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { InboxService } from 'src/app/shared/inbox.service';


@Component({
  selector: 'app-upcoming-appointments',
  templateUrl: './upcoming-appointments.component.html',
  styleUrls: ['./upcoming-appointments.component.css']
})
export class UpcomingAppointmentsComponent implements OnInit {
  appointmentlist:any;
  searchText='';
  p: number = 1;
 count: number = 5;
 RoleId:any;
 UserId:any;
 arraryLength:any;
 today:any;
  constructor(private _inboxService:InboxService,private _toastr:ToastrService) { 
   let day=new Date().getDate();
   let month=new Date().getMonth()+1;
   let year=new Date().getFullYear();
   this.today=day+" "+month+" "+year;
  }

  ngOnInit(): void {
   this.UserId=sessionStorage.getItem("id");
    this.RoleId=sessionStorage.getItem("roleId");
    

    if(this.RoleId==4)
    {
      this._inboxService.getAppointmentsForPatients().subscribe(res=>
        {         
          this.arraryLength= res.length; 
         this.appointmentlist =res; 
        });
    }
    else
    {
    this._inboxService.getAppointments().subscribe(res=>
      {        
        this.arraryLength= res.length; 
        this.appointmentlist =res;        
      });
    }    
  }

  acceptappointment(appointmentId:number)
  {  
    this._inboxService.acceptAppointment(appointmentId).subscribe(res=>
    {     
      this._toastr.success(res.value);
        this.ngOnInit();  
      });
  }  
  rejectappointment(appointmentId:number)
  {
    this._inboxService.rejectAppointment(appointmentId).subscribe(res=>
      {       
        this._toastr.success(res.value);
        this.ngOnInit();
 
      });
  }

  deleteappointment(appointmentId:number)
  {
    this._inboxService.deleteappointment(appointmentId).subscribe(res=>
      {
        this._toastr.success("Appointment cancelled");
        this.ngOnInit();        
      });
  }
}