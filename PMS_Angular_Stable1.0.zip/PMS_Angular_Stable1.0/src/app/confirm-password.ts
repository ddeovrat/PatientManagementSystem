
import { AbstractControl, FormGroup, ValidationErrors } from "@angular/forms";

// export class CustomValidators {

//     constructor() {}

  export function  match(c: AbstractControl) : ValidationErrors | null {

        if (c.get("Password")?.value !== c.get("ConPassword")?.value) {
       const dt= c.parent;  
       if(dt?.controls != undefined)  
       {
        console.log(dt?.controls);
       }    
       
        return {invalid: false};        
        }
        else{
            
            const dt= c.parent;  
            if(dt?.controls != undefined)  
       {
        debugger;
        console.log(dt);
        console.log(dt.value);
        console.log(dt?.controls.values);
       }   
            return {invalid: true};
        }
        
        //return null
        
        }
//}