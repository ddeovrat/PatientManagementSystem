import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-screen',
  templateUrl: './error-screen.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
  '../../assets/css/font-awesome.min.css',
  '../../assets/css/style.css','./error-screen.component.css']
  
})
export class ErrorScreenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
