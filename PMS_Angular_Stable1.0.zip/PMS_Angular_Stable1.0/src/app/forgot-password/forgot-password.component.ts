import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../shared/auth.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css',
  '../../assets/css/bootstrap.min.css',
  '../../assets/css/font-awesome.min.css',
  '../../assets/css/style.css'
  ]
})
export class ForgotPasswordComponent implements OnInit {

  
  email:string='';
  constructor(private _auth:AuthService) { }

  ngOnInit(): void {
  }

  ForgotPassForm: FormGroup = new FormGroup({
    Email: new FormControl("",[Validators.required,Validators.email]),
    Password: new FormControl("", [Validators.required,Validators.pattern("^[a-zA-Z0-9]{8,}$")]),
  },
  // { validators: [match] }
    );

  forgotPassword(form:FormGroup) {
    this._auth.forgotPassword(form.value.Email,form.value.Password);
  }

  Resetsubmit_click(form:FormGroup){
    this._auth.resetPassword(form.value.Email,form.value.OldPassword,form.value.Password);
    }

}
