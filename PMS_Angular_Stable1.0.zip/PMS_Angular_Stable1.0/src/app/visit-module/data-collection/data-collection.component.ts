import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import { Route,ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PatientService } from 'src/app/shared/patient.service';
import { VisitService } from 'src/app/shared/visit.service';

interface Diagnosisdt{
  DiagnosisId:number,
  VisitId:number,
  CreatedBy:string
}
interface Proceduredt{
  ProcedureId:number,
  VisitId:number,
  CreatedBy:string
}
interface Medicationdt{
  DrugId:number,
  VisitId:number,
  CreatedBy:string
}
interface SelectedDrug{
  DrugName:string,
  DrugForm:string,
  DrugStrength:string,
}

@Component({
  selector: 'app-data-collection',
  templateUrl: './data-collection.component.html',
  styleUrls: ['./data-collection.component.css']
})
export class DataCollectionComponent implements OnInit {

  public DiagnosisList:any;
  public ProcedureList:any;
  public MedicationList:any;
  PatId:any;
  AppId:any;
  Status:any;
  isLinear = false;
    Patientdata: any[]=[];
    UserRole:any;
  public IsSaveVisible:boolean=true;
  public IsUpdateVisible:boolean=false;
  public medicdt:SelectedDrug[]=[];
  
    VisitId:any;
    bloodPressure1:any;
    bloodPressure2:any;
    height:any;
    respirationRate:any;
    temperature:any;
    weight:any;
    diagnosisId:any[]=[];
    procedureId:any[]=[];
    drugId:any[]=[];
  
  race:string="";
    language:string="";
    gender:string="";
    ethnicity:string="";
    address:string="";
    userId:any;
    userDetailById:any;
    PatFormGroup:FormGroup;
    // public SelectedDrug={
    //   DrugName:"",
    //   DrugForm:"",
    //   DrugStrength:"",
    // }
    
  
    firstFormGroup = this._formBuilder.group({
      Height: ['', [Validators.required,Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      Weight: ['', [Validators.required,Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      BloodPressure1: ['', [Validators.required,Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      BloodPressure2: ['', [Validators.required,Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      Temperature: ['', [Validators.required,Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      RespirationRate: ['', [Validators.required,Validators.pattern(/^-?(0|[1-9]\d*)?$/)]],
      // AppointmentId:[''],
      // PatientId:[''],
    });
    secondFormGroup = this._formBuilder.group({
      Diagnosis: ['', Validators.required],
    });
    thirdFormGroup = this._formBuilder.group({
      Procedure: ['', Validators.required],
    });
    fourthFormGroup = this._formBuilder.group({
      Medication: ['', Validators.required],
    });
    
    constructor(private _formBuilder: FormBuilder,private _toastr:ToastrService, private _VisitService:VisitService,private _route:ActivatedRoute, private _PatientService:PatientService,private _router:Router) {
      this.PatFormGroup = _formBuilder.group({
        // gender: [{value: '', disabled: true}],
        // languages: [{value: '', disabled: true}],
        // race: [{value: '', disabled: true}],
        // ethinicity: [{value: '', disabled: true}],
        // address: [{value: '', disabled: true}],      
      });
     }
  
    ngOnInit(): void {
  
     this.AppId= this._route.snapshot.paramMap.get('AppId');
     this.PatId=this._route.snapshot.paramMap.get('PId');
     this.Status=this._route.snapshot.paramMap.get('Status');
     this.UserRole = sessionStorage.getItem('roleId');
     debugger;
     
     this.getPatient(this.PatId);
  
    this._VisitService.GetDiagnosisList().subscribe(data=>{
    this.DiagnosisList=data;
  })
  
  this._VisitService.GetProceduresList().subscribe(data=>{  
    this.ProcedureList=data;
  })
  
  this._VisitService.GetMedicationsList().subscribe(data=>{
    this.MedicationList=data;
    console.log(data);
  })
  
  if(this.Status=='InProcess'|| this.Status=='Completed'){
    this._VisitService.GetVitalSignsdata(this.AppId).subscribe(dt=>{
      debugger;
      this.VisitId=dt.visitId;
      this.height=dt.height;
      this.weight=dt.weight;
      this.bloodPressure1=dt.bloodPressure1;
      this.bloodPressure2=dt.bloodPressure2;
      this.respirationRate=dt.respirationRate;
      this.temperature=dt.temperature;
      var diagnosis:any[]=[]
      var procedure:any[]=[]
      var medication:any[]=[]
      for(let i=0; i<dt.diagnosisVisits.length;i++){
        diagnosis.push(dt.diagnosisVisits[i].diagnosisId)
      }
      this.diagnosisId=diagnosis;
      for(let i=0; i<dt.procedureVisits.length;i++){
        procedure.push(dt.procedureVisits[i].procedureId)
      }
      this.procedureId=procedure;
      for(let i=0; i<dt.medicationVisits.length;i++){
        medication.push(dt.medicationVisits[i].drugId)
      }
      this.drugId=medication;

      // this.diagnosisId=dt.diagnosisVisits[0].diagnosisId;
      // this.procedureId=dt.procedureVisits[0].procedureId;
      // this.drugId=dt.medicationVisits[0].drugId;
      if(this.diagnosisId[0]!=0 && this.procedureId[0]!=0 && this.drugId[0]!=0){
        this.IsSaveVisible=false;
        // this.IsUpdateVisible=true;
        if(this.UserRole!=2){
          this.secondFormGroup.disable();
          this.thirdFormGroup.disable();
          this.fourthFormGroup.disable();
          this.IsUpdateVisible=false;
        }
        else{
          this.IsUpdateVisible=true;
        }
      }else{
        this.IsSaveVisible=true;
        this.IsUpdateVisible=false;
      }
    })
  }
  
    }
  
    onSelectDrug(data:any){
      debugger;
      this.medicdt=[];
  var drugId=this.fourthFormGroup.value.Medication;
var filterdt:any[]=[];
data.forEach((element: any) => {
  filterdt.push(this.MedicationList.filter((x: { drugId: any; }) => x.drugId === element));
});
  // var dt=this.MedicationList.filter((x: { drugId: any; }) => x.drugId === drugId);
  //var dt=this.MedicationList.filter((x: { drugId: any; }) => x.drugId === drugId);
  for(let i=0; i<filterdt.length; i++){
    var drugdt={
      DrugName:filterdt[i][0].drugName,
      DrugForm:filterdt[i][0].drugForm,
      DrugStrength:filterdt[i][0].drugStrength
    }
    console.log(drugdt);
    this.medicdt.push(drugdt);
  }

  console.log(this.medicdt);
    }
  
    CheckForm1(form:FormGroup){
      debugger;
      if(form.valid){
        this.isLinear=false;
      }else{
  
        this.isLinear=true;
        this.validateAllFormFields(form);
      }
    }
    OnVitalSubmit(form:FormGroup){
      debugger;
      if(form.valid){
        var vitaldt={
          AppointmentId: Number(this.AppId),
          PatientId:Number(this.PatId),
          Height:form.value.Height,
          Weight:form.value.Weight,
          BloodPressure1:form.value.BloodPressure1,
          BloodPressure2:form.value.BloodPressure2,
          Temperature:form.value.Temperature,
          RespirationRate:String(form.value.RespirationRate),
          CreatedBy:sessionStorage.getItem('id')
        }
        
        this._VisitService.AddVitalsignData(vitaldt).subscribe(dt=>{
      debugger;
      console.log(dt);
      if(dt>0){
        
        this._VisitService.UpdateAppointmentStatus(Number(this.AppId),'InProcess').subscribe(data =>{
            if(data>0)
            {
              this._toastr.success('Vital signs saved');
            }
        });
        
      }else{
        this._toastr.error('Something went wrong'); 
      }
        })    
      }else{      
        this._toastr.warning('Please enter valid vital signs details');
        this.validateAllFormFields(form);
      }
    }
    OnVitalUpdate(form:FormGroup){
      debugger;
      if(form.valid){
        var vitaldt={
          VisitId:Number(this.VisitId),
          AppointmentId: Number(this.AppId),
          PatientId:Number(this.PatId),
          Height:form.value.Height,
          Weight:form.value.Weight,
          BloodPressure1:form.value.BloodPressure1,
          BloodPressure2:form.value.BloodPressure2,
          Temperature:form.value.Temperature,
          RespirationRate:String(form.value.RespirationRate)   
        }
        this._VisitService.UpdateVitalsignData(vitaldt).subscribe(dt=>{
          debugger;
          console.log(dt);
          if(dt>0){
            this._VisitService.UpdateAppointmentStatus(Number(this.AppId),'InProcess').subscribe(data =>{
              if(data>0)
              {
                this._toastr.success('Vital signs saved');
              }
          });
            
          }else{
            this._toastr.error('Something went wrong'); 
          }
            })    
          }else{      
            this._toastr.warning('Please enter valid vital signs details');
            this.validateAllFormFields(form);
          }
    }
  
    OnfinalSubmit(form1:FormGroup,form2:FormGroup,form3:FormGroup, form4:FormGroup){
      debugger;
  let IsValid=false;
  if(form1.valid){
    IsValid=true;
  console.log(form1);
  }else{
    IsValid=false;
    this._toastr.warning('Please enter valid vital signs details');
    this.validateAllFormFields(form1);
  }
   if(form2.valid){
    IsValid=true;
    console.log(form2);
  }else{
    IsValid=false;
    this._toastr.warning('Please enter valid diagnosis details');
    this.validateAllFormFields(form2);
  }
   if(form3.valid){
    IsValid=true;
    console.log(form3);
  }else{
    IsValid=false;
    this._toastr.warning('Please enter valid procedure details');
    this.validateAllFormFields(form3);
  }
  if(form4.valid){
    IsValid=true;
    console.log(form4);
  }else{
    IsValid=false;
    this._toastr.warning('Please enter valid medication details');
    this.validateAllFormFields(form4);
  }
  if(IsValid)
  {
    if(this.Status == 'InProcess' || this.Status =='Completed')
    {
      var vitaldt={
        AppointmentId: Number(this.AppId),
        VisitId:Number(this.VisitId),
        PatientId:Number(this.PatId),
        Height:form1.value.Height,
        Weight:form1.value.Weight,
        BloodPressure1:form1.value.BloodPressure1,
        BloodPressure2:form1.value.BloodPressure2,
        Temperature:form1.value.Temperature,
        RespirationRate:String(form1.value.RespirationRate),
        CreatedBy:sessionStorage.getItem('id')
      }
    }
    else
    {
      var vitaldt={
        AppointmentId: Number(this.AppId),
        VisitId:0,
        PatientId:Number(this.PatId),
        Height:form1.value.Height,
        Weight:form1.value.Weight,
        BloodPressure1:form1.value.BloodPressure1,
        BloodPressure2:form1.value.BloodPressure2,
        Temperature:form1.value.Temperature,
        RespirationRate:String(form1.value.RespirationRate),
        CreatedBy:sessionStorage.getItem('id')
      }
    }
    
  
    // var Diagnosisdt={
    //   DiagnosisId:form2.value.Diagnosis,
    //   VisitId:0,
    //   CreatedBy:sessionStorage.getItem('id')
    // }
    var digdt:Diagnosisdt[]=[];
    for(let i=0; i<form2.value.Diagnosis.length; i++){
      var obj1:Diagnosisdt=
      {
      DiagnosisId:form2.value.Diagnosis[i],
      VisitId:0,
      CreatedBy:String(sessionStorage.getItem('id'))
      }
    digdt.push(obj1);
  }

    // var Proceduredt={
    //   ProcedureId:form3.value.Procedure,
    //   VisitId:0,
    //   CreatedBy:sessionStorage.getItem('id')
    // }

    var procdt:Proceduredt[]=[];
    for(let i=0; i<form3.value.Procedure.length; i++){
     var obj2:Proceduredt={
      ProcedureId:form3.value.Procedure[i],
       VisitId:0,
       CreatedBy:String(sessionStorage.getItem('id'))
     }
     procdt.push(obj2);
    }

    // var Medicationdt={
    //   DrugId:form4.value.Medication,
    //   VisitId:0,
    //   CreatedBy:sessionStorage.getItem('id')
    // }
    var medcdt:Medicationdt[]=[];
    for(let i=0; i<form4.value.Medication.length; i++){
     var obj3:Medicationdt={
      DrugId:form4.value.Medication[i],
       VisitId:0,
       CreatedBy:"1"
     }
     medcdt.push(obj3);
    }

    // this._VisitService.AddMedicationData(Medicationdt).subscribe(dt4=>{
    //   debugger;
    //   dt4;
    // });
  
    this._VisitService.AddVitalsignData(vitaldt).subscribe(dt=>{
      debugger;
      if(dt!=null){
        
        
        if(this.Status == 'InProcess' || this.Status =='Completed')
        {
          digdt.forEach(element => {
            element.VisitId=Number(this.VisitId);
          });
          procdt.forEach(element => {
            element.VisitId=Number(this.VisitId);
          });
          medcdt.forEach(element => {
            element.VisitId=Number(this.VisitId);
          });
          
        }
        else
        {
          digdt.forEach(element => {
            element.VisitId=Number(dt);
          });
          procdt.forEach(element => {
            element.VisitId=Number(dt);
          });
          medcdt.forEach(element => {
            element.VisitId=Number(dt);
          });
        }
         this._VisitService.AddDiagnosisData(digdt).subscribe(dt2=>{
          if(dt2!=null){          
            this._VisitService.AddProcedureData(procdt).subscribe(dt3=>{            
              if(dt3>0){
                this._VisitService.AddMedicationData(medcdt).subscribe(dt4=>{
                  if(dt4>0){
                    this._VisitService.UpdateAppointmentStatus(Number(this.AppId),'Completed').subscribe(data =>{
                      if(data>0)
                      { 
                        this._toastr.success('Details saved successfully');
                        this._router.navigate(['../inbox/dashboard']);
                      }
                  });


                    
                  }                                
                });              
              }            
            })
          }
         })
      }
    });
  }
    }
    OnfinalUpdate(form1:FormGroup,form2:FormGroup,form3:FormGroup, form4:FormGroup){
      let IsValid=false;
      if(form1.valid){
        IsValid=true;
      console.log(form1);
      }else{
        IsValid=false;
        this._toastr.warning('Please enter valid vital signs details');
        this.validateAllFormFields(form1);
      }
       if(form2.valid){
        IsValid=true;
        console.log(form2);
      }else{
        IsValid=false;
        this._toastr.warning('Please enter valid diagnosis details');
        this.validateAllFormFields(form2);
      }
       if(form3.valid){
        IsValid=true;
        console.log(form3);
      }else{
        IsValid=false;
        this._toastr.warning('Please enter valid procedure details');
        this.validateAllFormFields(form3);
      }
      if(form4.valid){
        IsValid=true;
        console.log(form4);
      }else{
        IsValid=false;
        this._toastr.warning('Please enter valid medication details');
        this.validateAllFormFields(form4);
      }
      if(IsValid){
        var vitaldt={
          VisitId:Number(this.VisitId),
          AppointmentId: Number(this.AppId),
          PatientId:Number(this.PatId),
          Height:form1.value.Height,
          Weight:form1.value.Weight,
          BloodPressure1:form1.value.BloodPressure1,
          BloodPressure2:form1.value.BloodPressure2,
          Temperature:form1.value.Temperature,
          RespirationRate:String(form1.value.RespirationRate)        
        }
      
        var digdt:Diagnosisdt[]=[];
        for(let i=0; i<form2.value.Diagnosis.length; i++){
            var obj1:Diagnosisdt={
              DiagnosisId:form2.value.Diagnosis[i],
              VisitId:Number(this.VisitId),
              CreatedBy:String(sessionStorage.getItem('id'))
          }
          digdt.push(obj1);
        }
      
        var procdt:Proceduredt[]=[];
    for(let i=0; i<form3.value.Procedure.length; i++){
     var obj2:Proceduredt={
      ProcedureId:form3.value.Procedure[i],
       VisitId:Number(this.VisitId),
       CreatedBy:String(sessionStorage.getItem('id'))
     }
     procdt.push(obj2);
    }

    var medcdt:Medicationdt[]=[];
    for(let i=0; i<form4.value.Medication.length; i++){
     var obj3:Medicationdt={
      DrugId:form4.value.Medication[i],
      VisitId:Number(this.VisitId),
       CreatedBy:String(sessionStorage.getItem('id'))
     }
     medcdt.push(obj3);
    }
        // this._VisitService.AddMedicationData(Medicationdt).subscribe(dt4=>{
        //   debugger;
        //   dt4;
        // });
      
        this._VisitService.UpdateVitalsignData(vitaldt).subscribe(dt=>{
          debugger;
          if(dt!=null){
            // Diagnosisdt.VisitId=Number(dt);
            // Proceduredt.VisitId=Number(dt); 
            // Medicationdt.VisitId=Number(dt); 
            
             this._VisitService.UpdateDiagnosisVisitData(digdt).subscribe(dt2=>{
              if(dt2!=null){          
                this._VisitService.UpdateProcedureVisitData(procdt).subscribe(dt3=>{            
                  if(dt3>0){
                    this._VisitService.UpdateMedicationVisitData(medcdt).subscribe(dt4=>{
                      if(dt4>0){
                        this._VisitService.UpdateAppointmentStatus(Number(this.AppId),'Completed').subscribe(data =>{
                          if(data>0)
                          {  
                            this._toastr.success('Details updated successfully');
                            this._router.navigate(['../inbox/dashboard']);
                          }
                      });
                        
                      }                                
                    });              
                  }            
                })
              }
             })
          }
        });
      }
        }
    getPatient(id:number)
    {
      this._PatientService.getPatientDetails(id).subscribe((res: any[])=>{
        debugger;
        this.Patientdata= res;
        // console.log(this.Patientdata);
  
        // this._toastr.success("Demographics details added successfully");            
      });
    }
  
    validateAllFormFields(formGroup: FormGroup) {          
      Object.keys(formGroup.controls).forEach(field => {  
        const control = formGroup.get(field);             
        if (control instanceof FormControl) {             
          control.markAsDirty({ onlySelf: true });
        } else if (control instanceof FormGroup) {        
          this.validateAllFormFields(control);            
        }
      });
    }
  
  }
