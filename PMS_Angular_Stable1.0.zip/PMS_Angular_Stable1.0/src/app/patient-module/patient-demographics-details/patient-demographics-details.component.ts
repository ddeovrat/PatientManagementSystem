import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
//import { Session } from 'inspector';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PatientService } from '../../shared/patient.service'


@Component({
  selector: 'app-patient-demographics-details',
  templateUrl: './patient-demographics-details.component.html',
  styleUrls: ['./patient-demographics-details.component.css']
})
export class PatientDemographicsDetailsComponent implements OnInit {


  userId:any;



  month!: string;
  newdt!: string;

  value1:string="";
  value2:string="";

  allergyList: string[] = [];

  selectedvalue: any;
  userDetailById:any;

  datefromuserdetail: any = new Date();

  selectedAllergyvalue:any;
  selectedAllergytext:any;
  
 // allergyForm: FormGroup;
  registerForm: FormGroup;
  submitted = false;
  curdt: any;

  constructor(fb: FormBuilder, private _patientService:PatientService,private _toastr:ToastrService,private _router:Router) {


    
    let date= new Date();
     let dt=date.getDate();
     let mnth=date.getMonth();
    let yr=date.getFullYear();
     if(mnth<10){
     this.month="0"+mnth;
    }
     else{
    this.month=mnth.toString();
     } 
    if(dt<10){
    this.newdt="0"+dt;
     }
     else{
    this.newdt=dt.toString();
     }  
    this.curdt=yr+"-"+this.month+"-"+this.newdt;  
    

    
    this.registerForm = fb.group({
      title: [{value: '', disabled: true}, Validators.required],
      firstName: [{value: '', disabled: true}, Validators.required],
      lastName: [{value: '', disabled: true}, Validators.required],
      email: [{value: '', disabled: true}, [Validators.required, Validators.email]],
      dob: [{value: '', disabled: true}, Validators.required],
      age: [{value: '', disabled: true}, Validators.required],
      gender: ['', Validators.required],
      languages: ['', Validators.maxLength(50)],
      race: ['', [Validators.required,Validators.maxLength(50)]],
      ethinicity: ['', Validators.required],
      contact: [{value: '', disabled: true}, Validators.required, Validators.pattern("\\d{10}")],
      address: ['', Validators.required],
      
      emergencyContact: fb.group({
        title: ['', Validators.required],
        EfirstName: ['', Validators.required],
        ElastName: ['', Validators.required],
        Eemail: ['', [Validators.required, Validators.email]],
        Econtact: ['', Validators.required, Validators.pattern("\\d{10}")],
        Eaddress: ['', Validators.required],
        accessPortal: ['', Validators.required],
        relationship: ['', Validators.required],
      }),
      allergyDetails: fb.group({
        knownAllergies: ["false"],
        allergyId: [''],
        allergyType: [''],
        allergyName: [''],
        decription: [''],
        clinicalInformation: [''],
        allergyFatal: ['0'],
      }),
    
      DiseaseDetails: fb.group({
        knownDisease: ["false"],
        Information: [''],
        
      })



    });

    this.registerForm.get('dob')?.valueChanges.subscribe(val => {
      this.registerForm.get('age')?.setValue(this.getAge(val))
    });
  }

  ngOnInit(): void {
    this.userId=sessionStorage.getItem("id");

    this.getUserById(this.userId);

    this.getAllergyType();
   
    
  
  }

  userIdSession: number=0;
 
  submitRegisterForm() {
    this.submitted = true
    
    this.userIdSession = parseInt(this.userId);
    this._patientService.addPatientDemographics(this.userIdSession,this.registerForm).subscribe((res: string)=>{
            
    }); 
   
    this._patientService.addPatientEmergency(this.userIdSession,this.registerForm).subscribe(next => ((res:string)=>{
        console.log("Data posted Sucessfully");
    }),
      error => {
                  console.log("Data post Unsucessful");
              }
      //() => { this._router.navigate(['patient-module/details']);}
            
    ); 

    if(this.registerForm.value.allergyDetails.knownAllergies == "true")
    {
      this._patientService.addAllergies(this.userIdSession,this.registerForm,this.selectedAllergytext).subscribe((res: string)=>{
      
      
      });
    }

    if(this.registerForm.value.DiseaseDetails.knownDisease == "true")
    {
      this._patientService.addFamilyDisease(this.userIdSession,this.registerForm).subscribe((res: string)=>{
      
      
      });
    }

    this._toastr.success("Patient details added successfully");
    sessionStorage.setItem('userdetail','1');
    this._router.navigate(['../inbox/dashboard']);
    

  }

  get registerFormControl() {
    return this.registerForm.controls;
  }

   getAge(dateString:Date) {
    var today = new Date();
    var birthDate = new Date(dateString);

    var age = today.getFullYear() - birthDate.getFullYear();

    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age;
   }

   getAllergyType()
   {
    this._patientService.getAllergyType().subscribe((res: string[])=>{
      
      this.allergyList = res;

      // this._toastr.success("Demographics details added successfully");            
    });
   
  } 

  changeAllergyType(e:any)
  {
    this.selectedvalue =e.target.value;
    this.getAllergyName(this.selectedvalue);
    
  }

  changeAllergyName(e:any)
  {
    this.selectedAllergyvalue = e.target.value;
    this.selectedAllergytext = e.target.options[e.target.options.selectedIndex].text;
   // console.log(this.selectedvalue,this.selectedtext);
  }

  result:any;
  getAllergyName(selectedvalue:string)
  {
    this._patientService.getAllergyName(this.selectedvalue).subscribe((res:any[]) =>{
      this.result = res;
      });
      
  }

  getUserById(id:number)
  {
    this._patientService.getUserData(id).subscribe((res:any[]) =>{
      this.userDetailById = res;
      this.datefromuserdetail = this.getAge(this.userDetailById.dob);
      });
  }

  cancelbutton()
  {
    this._router.navigate(['login']);
  }
    

}
