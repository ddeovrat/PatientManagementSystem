import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoleGuard } from '../shared/role.guard';
import { PatientDemographicsDetailsComponent } from './patient-demographics-details/patient-demographics-details.component';
import { PatientDetailsComponent } from './patient-details/patient-details.component';

const routes: Routes = [
  {path:'',redirectTo:'patient-demographics-details',pathMatch:'full'},
  {path:'details', component:PatientDetailsComponent,canActivate:[RoleGuard]},
  {path:'patient-demographics-details', component:PatientDemographicsDetailsComponent,canActivate:[RoleGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientRoutingModule { }
