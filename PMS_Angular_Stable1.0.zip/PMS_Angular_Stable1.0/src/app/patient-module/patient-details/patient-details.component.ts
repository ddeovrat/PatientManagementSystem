import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/shared/patient.service';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css']
})
export class PatientDetailsComponent implements OnInit {

  userId:any;
  data:any[] = [];

  constructor(private _patientService:PatientService) { }

  ngOnInit(): void 
  {
    
    this.userId=sessionStorage.getItem("id");
    this.getPatient(this.userId);
  }

  getPatient(id:number)
  {
    this._patientService.getPatientDetails(id).subscribe((res: any[])=>{
      
      this.data= res;
      console.log(this.data);

      // this._toastr.success("Demographics details added successfully");            
    });
  }

}
