import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wip-page',
  templateUrl: './wip-page.component.html',
  styleUrls: ['../../assets/css/bootstrap.min.css',
  '../../assets/css/font-awesome.min.css',
  '../../assets/css/style.css','./wip-page.component.css']
})
export class WipPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
