import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(items: any[], fields:any[], value: string): any[] {
    
    if(!items) return [];
    if(!value) return items;
    return items.filter( item => {
      let itemFound: boolean = false;
      
       {{item.isActive == 0 && item.isBlocked==1 ? 'Blocked' : (item.isActive == 0 ? 'Deactive' : 'Active')}}

        if(!Number(value))
        {
          if(value.toLowerCase()=="blocked")
          {
            if (item[fields[fields.length-2]]==1 && item[fields[fields.length-3]]==0) {
              itemFound = true;
          }
          }
          
          else if(value.toLowerCase()=="deactive")
          {
            if (item[fields[fields.length-3]]==0 && item[fields[fields.length-2]]==0) {
              itemFound = true;
          }
          }
          else if(value.toLowerCase()=="active")
          {
            if (item[fields[fields.length-3]]==1) {
              itemFound = true;
          }
        }
          else{
          
          for (let i = 0; i < fields.length-3; i++) {
          if (item[fields[i]].toLowerCase().indexOf(value.toLowerCase()) !== -1) {
            itemFound = true;
            break;
          }
        }
        }
        }
        else 
        {
          let intval:number=parseInt(value);
          for (let i = fields.length-1; i >=3; i--) {
          if (item[fields[i]]==intval) {
            itemFound = true;
            break;
          }
        }
        }
      
     
      
      return itemFound;
      });
   }


}
