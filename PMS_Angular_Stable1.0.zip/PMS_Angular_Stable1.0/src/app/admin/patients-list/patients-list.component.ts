import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AdminService } from 'src/app/shared/admin.service';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';
import {MatSort, MatSortModule} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

@Component({
  selector: 'app-patients-list',
  templateUrl: './patients-list.component.html',
  styleUrls: ['./patients-list.component.css'
]
})
export class PatientsListComponent implements OnInit {

  searchText = '';
  
   // Pagination parameters.
 p: number = 1;
 count: number = 10;
 public userslist:any;
 sorteduserslist:any;
 sortcolumn:number=2;
 ascending:number=1;

 displayedColumns = ['firstName', "lastName", "id", "createdOnUtc", "email", "status","EditStatus"];
 dataSource!: MatTableDataSource <any > ;

 @ViewChild(MatPaginator)
 paginator!: MatPaginator;
@ViewChild(MatSort)
 sort!: MatSort;

  constructor(private  _adminService:AdminService,private _toastr:ToastrService) { }

  ngOnInit(): void {
    this._adminService.getPatientUsers().subscribe(data=>{
      this.userslist=data;
      const patientData:Record<string, any>[] =data.map((value: { [x: string]: any; }) => ({

        isActive:value['isActive'],
        isBlocked:value['isBlocked'],
        firstName: value['firstName'],
        lastName:value['lastName'],
        id:value['id'],       
        createdOnUtc:value['createdOnUtc'],
        email:value['email'],     
        
        
      }))
         
     this.dataSource = new MatTableDataSource(patientData); 
     console.log(this.dataSource);
        console.log(this.dataSource.data);
     this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort; 
    
      
    }
      );

  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
      
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }


  updatepatienttatus(patientid:number,status:string)
  {
    this._adminService.changePatientStatus(patientid,status).subscribe(res=>    
      {
            this._toastr.show("Status has been updated successfully");
            this.ngOnInit();
      });
  }
}






