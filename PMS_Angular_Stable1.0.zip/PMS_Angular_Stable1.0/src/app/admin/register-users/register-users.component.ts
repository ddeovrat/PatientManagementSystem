import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../../../app/shared/auth.service';
import { AdminService } from '../../../app/shared/admin.service'
import { NgModule } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AngularFireAuth } from '@angular/fire/compat/auth';

@Component({
  selector: 'app-register-users',
  templateUrl: './register-users.component.html',
  styleUrls: ['./register-users.component.css']
})
export class RegisterUsersComponent implements OnInit {
  
  ystDate:any;
  curdt:any;  
  month!: string;
  date!:string;
  Pass:any;
  ConPass:any;
  email:string='';
  password:string='';
  confirmPassword:string='';
  result:number=0;
  constructor(private _authService: AuthService,private _fireauth:AngularFireAuth,private  route:ActivatedRoute,private _auth:AuthService, private _adminService:AdminService,private _toastr:ToastrService, private _router:Router) {
    //this.currentDate =this.datepipe.transform((new Date), 'dd/MM/yyyy');
    let date= new Date();
    
    let dt=date.getDate();
    let mnth=date.getMonth();
    let yr=date.getFullYear();
    
    if(mnth<10){
      this.month="0"+mnth;
    }
    else{
      this.month=mnth.toString();
    }
    if(dt<10){
      this.date="0"+dt;
    }
    else{
      this.date=dt.toString();
    }    
     this.curdt=yr+"-"+this.month+"-"+this.date;  
   }  
    
   HospitalUserRegForm: FormGroup = new FormGroup({
    title: new FormControl("Mr.",Validators.required),
    FirstName: new FormControl("",Validators.required),
    LastName: new FormControl("",Validators.required),
    ContactNo: new FormControl("",[Validators.required, Validators.pattern("\\d{10}")]),
    Email: new FormControl("",[Validators.required,Validators.email]),
    DOB: new FormControl("", [Validators.required]),
    RoleId:new FormControl("",[Validators.required]),
    id:new FormControl()
  },
    );
    
  ngOnInit(): void {
    this.HospitalUserRegForm.patchValue({title:'Mr.'});
    let selectedid  =this.route.snapshot.params["userId"];
    if(selectedid != null || selectedid!= undefined)
   { this.GetUserDetails(selectedid);}
  }
  

  userId:number=0;

  register(data:FormGroup){

    if(this.userId != 0)
    {
      this._adminService.updateHospitalUser(data.value).subscribe((res: string)=>{
        this._toastr.success('User details updated successfully','CT Hospital');
        this._router.navigate(['/admin/UsersList']);
      });
    }
    else{
      
      delete data.value['id'];
    if(data.value.RoleId=="2")
    data.value.RoleId=2;
    else if(data.value.RoleId=="1")
    data.value.RoleId=1;
    else 
    data.value.RoleId=3;   
    this._fireauth.createUserWithEmailAndPassword(data.value.Email,'Default123').then(fireRes=>{
      this._adminService.addHospitalUser(data).subscribe((res: string)=>{
        this._toastr.success('User registered successfully','CT Hospital');
        this._authService.sendEmailForVerification(fireRes.user);
        this.HospitalUserRegForm.reset();
      },err=>{
        fireRes.user?.delete();
        this._toastr.error('Registration Failed');
      });       
    },err=>{
      this._toastr.error('Registration Failed');
    })    
  }
  }

   formatDate(date:any) {
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) 
        month = '0' + month;
    if (day.length < 2) 
        day = '0' + day;

    return [year, month, day].join('-');
}

  GetUserDetails(id:any){  
    debugger; 
    this._adminService.getHospitalUserById(Number(id)).subscribe((res)=>{
      let data = JSON.parse(res);
      this.userId = data.id;
      this.HospitalUserRegForm.patchValue({id:data.id});
       this.HospitalUserRegForm.patchValue({title:data.title});
       this.HospitalUserRegForm.patchValue({FirstName:data.firstName});
       this.HospitalUserRegForm.patchValue({LastName:data.lastName});
       this.HospitalUserRegForm.patchValue({ContactNo:data.contactNo});
       this.HospitalUserRegForm.patchValue({Email:data.email});
       this.HospitalUserRegForm.patchValue({DOB: this.formatDate(data.dob)});
       this.HospitalUserRegForm.patchValue({RoleId:data.roleId});
    },
    err=>{
      this._toastr.error('Failed to load user details');
    });
  }

}
