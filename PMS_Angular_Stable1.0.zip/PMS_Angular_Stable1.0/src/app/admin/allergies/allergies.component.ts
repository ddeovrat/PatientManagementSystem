import { Component, OnInit } from '@angular/core';
import  Allergy  from '../../models/allergy';

@Component({
  selector: 'app-allergies',
  templateUrl: './allergies.component.html',
  styleUrls: ['./allergies.component.css','./../../../assets/css/bootstrap.min.css',
  './../../../assets/css/font-awesome.min.css',
  './../../../assets/css/style.css','./../../../assets/css/bootstrap-datetimepicker.min.css',
  './../../../assets/css/select2.min.css','./../../../assets/css/dataTables.bootstrap4.min.css']
})
export class AllergiesComponent implements OnInit {

  allergylist: Allergy[] = [];
  

  constructor() { }

  ngOnInit(): void {
  }

}
