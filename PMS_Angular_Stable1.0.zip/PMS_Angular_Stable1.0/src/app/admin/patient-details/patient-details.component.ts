import { Component, OnInit } from '@angular/core';
import User from './../../models/user';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css','./../../../assets/css/bootstrap.min.css',
  './../../../assets/css/font-awesome.min.css',
  './../../../assets/css/style.css','./../../../assets/css/bootstrap-datetimepicker.min.css',
  './../../../assets/css/select2.min.css','./../../../assets/css/dataTables.bootstrap4.min.css']
              
})
export class PatientDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

  public userslist:User[] = 
    [
      { id:1, firstname: 'Manish', lastname: 'Senapati', dob: '1997', email: 'xyz@gmail.com', contactno: "123456", address: 'Navi Street' },
      { id:2, firstname: 'Aditya', lastname: 'More', dob: '1997', email: 'xyz@gmail.com', contactno: "123456", address: 'Navi Street' },
      { id:3, firstname: 'Deepankar', lastname: '', dob: '1997', email: 'xyz@gmail.com', contactno: "123456", address: 'Navi Street' },
      { id:4, firstname: 'Madhavi', lastname: 'Yadav', dob: '1997', email: 'xyz@gmail.com', contactno: "123456", address: 'Navi Street' },
      { id:5, firstname: 'Namrata', lastname: 'Chavan', dob: '1997', email: 'xyz@gmail.com', contactno: "123456", address: 'Navi Street' }
    
    ];

}
