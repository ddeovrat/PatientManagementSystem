import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoleGuard } from '../shared/role.guard';
import { PatientsListComponent } from './patients-list/patients-list.component';
import { RegisterUsersComponent } from './register-users/register-users.component';
import { UsersListComponent } from './users-list/users-list.component';

// canActivate:[RoleGuard]

const routes: Routes = [
  {path:'',redirectTo:'UsersList',pathMatch:'full'},
{path:'UsersList', component:UsersListComponent,canActivate:[RoleGuard]},
{path:'PatientList', component:PatientsListComponent,canActivate:[RoleGuard]},
{path:'RegisterUsers', component:RegisterUsersComponent,canActivate:[RoleGuard]},
{ path: 'RegisterUsers/:userId', component: RegisterUsersComponent,canActivate:[RoleGuard]}
//{path:'PatientList', component:PatientsListComponent,canActivate:[RoleGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
