import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, ValidationErrors } from '@angular/forms';
import { AuthService } from '../shared/auth.service';
import { PatientLoginRegisterService } from '../shared/patient-login-register.service';


@Component({
  selector: 'app-register-patient',
  templateUrl: './register-patient.component.html',
  styleUrls: ['./register-patient.component.css',
  '../../assets/css/bootstrap.min.css',
  '../../assets/css/font-awesome.min.css',
  '../../assets/css/style.css'
  ]
})
export class RegisterPatientComponent implements OnInit {

  ystDate:any;
  curdt:any;  
  month!: string;
  date!:string;
  Pass:any;
  ConPass:any;
  email:string='';
  password:string='';
  confirmPassword:string='';
  result:number=0;
  constructor(private _auth:AuthService, private _registerPatientService:PatientLoginRegisterService) {
    //this.currentDate =this.datepipe.transform((new Date), 'dd/MM/yyyy');
    let date= new Date();
    
    let dt=date.getDate();
    let mnth=date.getMonth();
    let yr=date.getFullYear();
    
    if(mnth<10){
      this.month="0"+mnth;
    }
    else{
      this.month=mnth.toString();
    }
    if(dt<10){
      this.date="0"+dt;
    }
    else{
      this.date=dt.toString();
    }    
     this.curdt=yr+"-"+this.month+"-"+this.date;  
   }  
    
  PatientRegForm: FormGroup = new FormGroup({
    title: new FormControl("",[Validators.required]),
    FirstName: new FormControl("",Validators.required),
    LastName: new FormControl("",Validators.required),
    ContactNo: new FormControl("",[Validators.required, Validators.pattern("^[0-9]{10}$")]),
    Email: new FormControl("",[Validators.required,Validators.email]),
    Password: new FormControl("", [Validators.required,Validators.pattern("^[a-zA-Z0-9]{8,}$")]),
    ConPassword: new FormControl("",[Validators.required,Validators.pattern("^[a-zA-Z0-9]{8,}$")]),
    DOB: new FormControl("", [Validators.required])
  },
    );

  ngOnInit(): void {
    this.PatientRegForm.patchValue({ title:'Mr.'});
  }

  register(data:FormGroup){
    if(this.PatientRegForm.valid)
      this._auth.register(data);  
  }

}
