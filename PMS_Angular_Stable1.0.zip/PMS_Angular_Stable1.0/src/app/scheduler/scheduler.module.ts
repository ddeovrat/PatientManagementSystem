import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SchedulerRoutingModule } from './scheduler-routing.module';
import { ViewScheduleComponent } from './view-schedule/view-schedule.component';
import { ScheduleModule , ScheduleAllModule, DayService,WeekService,MonthService, ScheduleComponent} from '@syncfusion/ej2-angular-schedule'


@NgModule({
  declarations: [
    ViewScheduleComponent
  ],
  imports: [
    CommonModule,
    SchedulerRoutingModule,
    ScheduleModule,
    ScheduleAllModule
  ],
  providers: [
    DayService,
    WeekService,
    MonthService
  ]
})
export class SchedulerModule { }
