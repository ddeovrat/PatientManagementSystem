export enum EAppointmentStatus {
    Requested ="Requested", 
    Approved = "Approved", 
    Rejected = "Rejected", 
    Completed = "Completed",
    Inprogress = "Inprogress",
    Cancelled = "Cancelled"
}
