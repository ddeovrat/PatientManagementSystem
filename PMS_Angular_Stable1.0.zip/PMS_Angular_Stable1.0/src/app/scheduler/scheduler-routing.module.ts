import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoleGuard } from '../shared/role.guard';
import { ViewScheduleComponent } from './view-schedule/view-schedule.component';

const routes: Routes = [
  {path:'',redirectTo:'ViewSchedule',pathMatch:'full'},
  {path:'ViewSchedule', component:ViewScheduleComponent,canActivate:[RoleGuard]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SchedulerRoutingModule { }
