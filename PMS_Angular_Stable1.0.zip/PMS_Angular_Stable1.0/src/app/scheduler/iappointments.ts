import { EAppointmentStatus } from "./eappointment-status"

export interface IAppointments {
    AppointmentID:number
    meetingTitle: string,
    description:string,
    startTime:Date,
    endTime:Date,
    comments:string,
    UserID:number,
    Command:string,
    Status:EAppointmentStatus,
    PatientID: number
}
