import { Component, OnInit } from '@angular/core';
import { EventSettingsModel, View, EventRenderedArgs, DayService, WeekService, WorkWeekService,ActionEventArgs, PopupOpenEventArgs, EJ2Instance, WorkHoursModel,
  MonthService, AgendaService, ResizeService, DragAndDropService, ScheduleComponent,  RenderCellEventArgs } from '@syncfusion/ej2-angular-schedule';
import { L10n } from '@syncfusion/ej2-base';
import { SchedulerService } from 'src/app/shared/scheduler.service';
import { ToastrService } from 'ngx-toastr';
import { DropDownList } from '@syncfusion/ej2-angular-dropdowns';
import { DateTimePicker } from '@syncfusion/ej2-angular-calendars';
import { FormValidators, FormValidator, TextBox } from "@syncfusion/ej2-angular-inputs";
import { ButtonComponent } from '@syncfusion/ej2-angular-buttons';
import { EAppointmentStatus } from '../eappointment-status';
import { IAppointments } from '../iappointments';
import { map } from 'rxjs/operators'

L10n.load({
  'en-US': {
      'schedule': {
          'saveButton': 'Add',
          'cancelButton': 'Close',
          'deleteButton': 'Remove',
          'newEvent': 'Add Appointment',
          'editEvent': 'Edit Appointment',
          'deleteEvent': 'Delete Appointment'
    },
  }
});

@Component({
  selector: 'app-view-schedule',
  templateUrl: './view-schedule.component.html',
  styleUrls: ['./view-schedule.component.css'],
  providers: [DayService, WeekService, WorkWeekService, MonthService]
})
export class ViewScheduleComponent implements OnInit {

  constructor(private service:SchedulerService, private _toastr:ToastrService) {  }
  
  ngOnInit(): void {
    this.GetPhysician();
    this.GetPatients();
  }


  public RoleId =  sessionStorage.getItem('roleId');
  public UserId =  sessionStorage.getItem('id');
  public  physicianarr: any[] = [];
  public  patientarr: any[] = [];


  GetPhysician(){
    this.service.getPhysicians().subscribe(
     data=>{this.physicianarr =data;
     },
     err=>{
       this._toastr.error('Failed to load physicians','CT Hospital');
     }
   );  
 }

 GetPatients(){
    this.service.getPatients().subscribe(
     data=>{this.patientarr = data;
     },
     err=>{
       this._toastr.error('Failed to load patients','CT Hospital');
     }
   );   
}

    public validator: FormValidator | undefined;
    public selectedDate: Date = new Date();
    public setView:View = "Month";
    public views: Array<string> = ['Day', 'Week', 'WorkWeek', 'Month'];
    public showQuickInfo: Boolean = true;
    public eventSettings: EventSettingsModel = {
        dataSource:[         
        ],
      enableTooltip: true
    };
    public workWeekDays: number[]= [1, 2, 3, 4, 5, 6];
    public workHours: WorkHoursModel = { start: '09:00', end: '20:00' };
    public today = new Date();
    public minDate = new Date(this.today.getFullYear(), this.today.getMonth()-3, this.today.getDate());
    public maxDate = new Date(this.today.getFullYear(), this.today.getMonth()+3, this.today.getDate());

    Status: any = [                        // <-- you still need the array
      EAppointmentStatus.Approved,
      EAppointmentStatus.Rejected,
      EAppointmentStatus.Requested,
      EAppointmentStatus.Completed,
      EAppointmentStatus.Inprogress,
      EAppointmentStatus.Cancelled
    ];

    //Data Binding and adding with api 
    public temp = true;
    
    
    onBound(args: any): void {
      if (this.temp) {
        let schObj = (document.querySelector('.e-schedule') as any).ej2_instances[0]; 
        this.service.getAppointments().subscribe((data:any ) => {
          console.log(data);
          debugger;
          
       const appointmentsData:Record<string, any>[] =data.map((value: { [x: string]: any; }) => ({
          
           Id: value['appointmentId'],
           Subject:value['meetingTitle'],
           StartTime:value['startTime'], //new Date(2021, 1, 14, 10, 0),
           EndTime: value['endTime'],//new Date(2021, 1, 14, 11, 30),
           Description:value['description'],
           IsBlock:false,
           EventType:value['status'],
           IsReadonly:true,
           PatientID:value['patientId'],
           PatientName:value['patientName'],
           PhysicianName:value['physicianName'],
           UserId:value['userId'],
           Comment:value['comments'],
           Status:value['status']
         }))
  
         appointmentsData.forEach(v=>{
              if(v['EventType']==EAppointmentStatus.Approved)
              {
                if(Number(this.RoleId)  == 4)
                {
                  v['IsReadonly']=true;
                }                
               // v['IsBlock']=true;
              }
             else if(v['EventType']== EAppointmentStatus.Completed)
              {
              v['IsReadonly'] =true;
              //v['IsBlock'] =true;
              }
              else if(v['EventType']== EAppointmentStatus.Cancelled)
              {
              v['IsReadonly'] =true;
              }
             else
              {
              v['IsReadonly']=false;
              }
          });
        schObj.eventSettings.dataSource = appointmentsData; 
        this.temp = false; 
  
      })
        this.temp = false;
      }
    }

    onBegin(args: any): void {
    
      if (args.requestType === "eventCreate") {
        let schObj = (document.querySelector(".e-schedule") as any).ej2_instances[0];
        let NewApointment:IAppointments={
          AppointmentID:0,
          meetingTitle: args.data[0].Subject,
          description:args.data[0].Description,
          startTime:args.data[0].StartTime,
          endTime:args.data[0].EndTime,
          comments:'Test',
          UserID:(Number)(args.data[0].Physician),
          Command:"Add",
          Status:EAppointmentStatus.Requested,
          PatientID: (Number)(args.data[0].Patient)
         };
         this.service.addAppointment(NewApointment).subscribe((data: {}) => { 
          this._toastr.success('Appointment scheduled successfully.','CT Hospital');
          // console.log(data);
         });  
       
      } 
      else if (args.requestType === "eventChange") {
        let schObj = (document.querySelector(".e-schedule") as any).ej2_instances[0];
        
        let NewApointment:IAppointments={
          AppointmentID:args.data.Id,
          meetingTitle: args.data.Subject,
          description:args.data.Description,
          startTime:(args.data.StartTime),
          endTime:(args.data.EndTime),
          comments:args.data.Comment,
          UserID:(Number)(args.data.Physician),
          Command:"Update",
          Status:args.data.Status,
          PatientID: (Number)(args.data.Patient)
         };
         debugger;
        console.log(NewApointment);
         if(NewApointment != undefined)
          { this.service.updateAppointment(NewApointment).subscribe((data: {}) => {
             this._toastr.success('Appointment updated successfully.','CT Hospital');
           });  
          }
      } 
      else if (args.requestType === "eventRemove") {
        let schObj = (document.querySelector(".e-schedule") as any)
        .ej2_instances[0];
        let NewApointment:IAppointments={
          AppointmentID:args.data[0].Id,
          meetingTitle: args.data[0].Subject,
          description:args.data[0].Description,
          startTime:new Date(args.data[0].StartTime),
          endTime:new Date(args.data[0].EndTime),
          comments:'Test',
          UserID:(Number)(args.data[0].Physician),
          Command:"Delete",
          Status:EAppointmentStatus.Requested,
          PatientID: (Number)(args.data[0].Patient)
         };
         debugger;
         if(NewApointment != undefined)
         { 
         this.service.deleteAppointment(NewApointment.AppointmentID).subscribe((data:any) => {
           debugger;
           const appointmentsData:Record<string, any>[] =data.map((value: { [x: string]: any; }) => ({
          
            Id: value['appointmentId'],
            Subject:value['meetingTitle'],
            StartTime:value['startTime'], //new Date(2021, 1, 14, 10, 0),
            EndTime: value['endTime'],//new Date(2021, 1, 14, 11, 30),
            Description:value['description'],
            IsBlock:false,
            EventType:value['status'],
            IsReadonly:true,
            PatientID:value['patientId'],
            PatientName:value['patientName'],
            UserId:value['userId'],
            Comment:value['comments'],
            Status:value['status']
          }))
          appointmentsData.forEach(v=>{
            if(v['EventType']==EAppointmentStatus.Approved){
              if(Number(this.RoleId) ==4 ){
              v['IsReadonly']=true;}
           }
           else
           {
            v['IsReadonly']=false;
           }
        })
           schObj.eventSettings.dataSource = appointmentsData; 
           this._toastr.success('Appointment cancelled successfully.','CT Hospital');
          });
        }
         };  
      }


    onPopupOpen(args: PopupOpenEventArgs): void {
   
      if (args.type === "Editor") {
        
        if (args.target?.classList.contains('e-appointment')) {
          let saveBtnElement: HTMLInputElement = args.element.querySelector('.e-event-save') as HTMLInputElement;
        if (saveBtnElement) {
          saveBtnElement.innerText = "UPDATE";
       }
        }
        else{
          let saveBtnElement: HTMLInputElement = args.element.querySelector('.e-event-save') as HTMLInputElement;
          if (saveBtnElement) {
            saveBtnElement.innerText = "REQUEST";
         }
        }
        
        let deleteElement: HTMLInputElement = args.element.querySelector('.e-event-delete') as HTMLInputElement;
        if (deleteElement) {
          deleteElement.innerText = "CANCEL";
       }
        let headerElement: HTMLInputElement = args.element.querySelector('.e-title-text') as HTMLInputElement;
        if (headerElement) {
          headerElement.innerText = "Schedule Appointment";
       }
        
          let subjectElement: HTMLInputElement = args.element.querySelector('#Subject') as HTMLInputElement;
          if (subjectElement) {
              subjectElement.value = ((<{ [key: string]: Object; }>(args.data))['Subject'] as string) || "";
           }
           
           let idElement: HTMLInputElement = args.element.querySelector('#Id') as HTMLInputElement;
          if (idElement) {
            idElement.hidden=true;
            idElement.value = ((<{ [key: string]: Object; }>(args.data))['Id'] as string) || "";
           }
          
          let startElement: HTMLInputElement = args.element.querySelector('#StartTime') as HTMLInputElement;
          if (!startElement.classList.contains('e-datetimepicker')) {
              startElement.readOnly=false;
              startElement.value = (<{ [key: string]: Object; }>(args.data))['StartTime'] as string;
              new DateTimePicker({ value: new Date(startElement.value) || new Date() }, startElement);
          }
          let endElement: HTMLInputElement = args.element.querySelector('#EndTime') as HTMLInputElement;
          if (!endElement.classList.contains('e-datetimepicker')) {
              endElement.readOnly=false;
              endElement.value = (<{ [key: string]: Object; }>(args.data))['EndTime'] as string;
              new DateTimePicker({ value: new Date(endElement.value) || new Date() }, endElement);
          }
          let descriptionElement: HTMLInputElement = args.element.querySelector('#Description') as HTMLInputElement;
          if (descriptionElement) {
              descriptionElement.value = (<{ [key: string]: Object; }>(args.data))['Description'] as string || "";
          }
  
          let commentElement: HTMLInputElement = args.element.querySelector('#Comment') as HTMLInputElement;
          if (commentElement) {
            commentElement.value = (<{ [key: string]: Object; }>(args.data))['Comment'] as string || "";
          }
  
          let statusElement: HTMLInputElement = args.element.querySelector('#Status') as HTMLInputElement;
              if (!statusElement.classList.contains('e-dropdownlist')) {
                if(Number(this.RoleId )==4)
                {
                  this.Status = [EAppointmentStatus.Requested];
                }
                  let dropDownListObject: DropDownList = new DropDownList({
                      placeholder: 'Choose status', 
                      dataSource: this.Status,
                      //fields: { text: 'name', value: 'id' },                    
                      value : (<{ [key: string]: Object; }>(args.data))['Status'] as string || EAppointmentStatus.Requested
                    });
                  dropDownListObject.appendTo(statusElement);
                  statusElement.setAttribute('name', 'Status');  
              }
  
          let patientElement: HTMLInputElement = args.element.querySelector('#Patient') as HTMLInputElement;
              if (!patientElement.classList.contains('e-dropdownlist')) {
                  let dropDownListObject: DropDownList = new DropDownList({
                      placeholder: 'Choose patient', 
                      dataSource: this.patientarr,
                      fields: { text: 'name', value: 'id' },
                      value : (<{ [key: string]: Object; }>(args.data))['PatientID'] as string || ""
                  });
                  dropDownListObject.appendTo(patientElement);
                  patientElement.setAttribute('name', 'Patient');
                   if(Number(this.RoleId)== 4 && this.UserId != "")
                  {
                    dropDownListObject.value =  Number(this.UserId);
                    patientElement.parentElement?.classList.add("e-disabled");
                    patientElement?.classList.add("e-disabled");
                    patientElement.readOnly = true;
                  }
                  else{
                    patientElement.readOnly = false;
                    patientElement?.classList.remove("e-disabled");
                  }
              }
              
  
              let physicianElement: HTMLInputElement = args.element.querySelector('#Physician') as HTMLInputElement;
              if (!physicianElement.classList.contains('e-dropdownlist')) {
                  let dropDownListObject: DropDownList = new DropDownList({
                      placeholder: 'Choose physician', 
                      dataSource: this.physicianarr,
                      fields: { text: 'name', value: 'id' },
                      value : (<{ [key: string]: Object; }>(args.data))['UserId'] as string || ""
                  
                  });
                  dropDownListObject.appendTo(physicianElement);
                  physicianElement.setAttribute('name', 'Physician');
                  if(Number(this.RoleId)== 2 && this.UserId != "")
                  {
                    
                    physicianElement.parentElement?.classList.add("e-disabled");
                    dropDownListObject.value =  Number(this.UserId);
                    physicianElement.classList.add("e-disabled");
                    physicianElement.readOnly = true;
                  }
                  else{
                    physicianElement.readOnly = false;
                    physicianElement.classList.remove("e-disabled");
                  }
              }
              
  
  
        const formElement: HTMLElement = args.element.querySelector(".e-schedule-form") as HTMLElement;
        this.validator = (formElement as EJ2Instance).ej2_instances[0] as FormValidator;
        this.validator.addRules("Status", { required: [true, "This field is required."]});
        if (args.target?.classList.contains("e-work-cells")) {
          args.element.querySelector(".e-event-save")!.classList.add("e-custom-disable");
        }
      }
  
      if (args.type === "QuickInfo") {
        if (
          !args.element.querySelector(".status-row") &&
          args.target?.classList.contains("e-appointment")
        ) {
          
          const el = document.createElement('div');
          el.innerHTML = "<div class='e-people icon e-icons'></div><div class='e-location-details e-text-ellipsis'>" +"Patient : "+
          args?.data?.['PatientName'] +  "</br> Physician : "+args?.data?.['PhysicianName'] +
          "</div>"
          el.className=  "e-location";
          el.style.paddingTop = "16px";
          el.style.fontSize = "14px";
          el.style.display= "flex";
  
          let contentElement: HTMLElement = <HTMLElement>(
            args.element.querySelector(".e-popup-content")
          );
          contentElement.append(el);
         
        }
      }   
  }

  public onRenderCell(args: RenderCellEventArgs) {
    
    if(args.elementType === 'workCells' && args.date?.getHours() === 13) {
      args.element.classList.add('e-lunch-hours');
    }
    if(args.elementType === 'workCells' && args.date?.getHours() === 14) {
      args.element.classList.add('e-lunch-hours');
    }
     if (args.elementType === "workCells" && args.date!.getTime() <= new Date().getTime() && !args.element.classList.contains("e-disable-dates")) {
       args.element.classList.add("e-disable-dates");
       args.element.classList.add("e-disable-cell");
     }
  }

  public onEventRendered(args: EventRenderedArgs): void {
   if(args.data['EventType']== EAppointmentStatus.Approved)
   {
     if(Number(this.RoleId)  == 4){
     args.data['IsReadonly'] =true;}
     //args.data['IsBlock'] =true;
   }
   else if(args.data['EventType']== EAppointmentStatus.Completed)
   {
    args.data['IsReadonly'] =true;
    //args.data['IsBlock'] =true;
   }
   else if(args.data['EventType']== EAppointmentStatus.Cancelled)
   {
    args.data['IsReadonly'] =true;
   }
   switch (args.data['EventType']) {
     case EAppointmentStatus.Requested:
           (args.element as HTMLElement).style.backgroundColor = '#FFFF33';
           break;
       case EAppointmentStatus.Approved:
           (args.element as HTMLElement).style.backgroundColor = '#7CFC00';
           break;
       case EAppointmentStatus.Rejected:
           (args.element as HTMLElement).style.backgroundColor = '#FF0000';
           break;
       case EAppointmentStatus.Completed:
           (args.element as HTMLElement).style.backgroundColor = '#955251';
           break;
       case EAppointmentStatus.Cancelled:
           (args.element as HTMLElement).style.backgroundColor = '#6c757d';
           break;
       case EAppointmentStatus.Inprogress:
            (args.element as HTMLElement).style.backgroundColor = '#007bff';
            break;
   }

 }

 public isBreak(date: Date) {
  if(date.getHours() === 13) {
    return '<div class="e-break">Break Time</div>';
  }
  if(date.getHours() === 14) {
    return '<div class="e-break">Break Time</div>';
  }
 return ''
}

}
