import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable,catchError, map, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private readonly _apiUrl = "https://localhost:44378/gateway";
  constructor(private _http:HttpClient, private _toastr:ToastrService) { }
  addHospitalUser(val:any):Observable<any>{
    //Change  
    return this._http.post<any>(this._apiUrl+'/admin/AddHospitalUser',val.value,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;
    }),catchError((error) => {    // handle error       
        return error;
      })
    );
  }

  login(email:string,password:string):Observable<any>{
    return this._http.post<any>(this._apiUrl+"/auth/UserLogin/{username}/{password}"+email+"/"+password,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
    if(data.status==200)
    {
      return data;
    }
    else if(data.status==400)
    {
      return "User account is inactive/blocked or user not found";
    }
    else 
    {
      return "User is locked/Invalid Credentials";
    }
    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }


  getHospitalUsers():Observable<any>
  {       
    return this._http.get<any>(this._apiUrl+"/admin/GetHospitalUsers",{responseType:'json' })
    .pipe(map((data:any)=>{    
      return data;
    }),catchError((error) => {    // handle error
      if (error.status == 404) {
        //Handle Response code here
      }
      return error;  
  }));
  }

  getHospitalUserById(id:number):Observable<any>

  {

  return this._http.get<any>(this._apiUrl+"/admin/GetHospitalUser/"+id,{responseType:'text' as 'json'})

  .pipe(map((data:any)=>{

    return data;

  }),catchError((error) => {    // handle error

    if (error.status == 404) {

      //Handle Response code here

    }

    return error;

})

  );

  }


  getHospitalUsersByName(name:string):Observable<any>
  {
    return this._http.get<any>(this._apiUrl+"/admin/GetHospitalUsers/"+name,{responseType:'text' as 'json'})
    .pipe(map((data:any)=>{

      if(data.status==200)
      {
        return data;
      }
      else if(data.status==404)
      {
        return "No user with this name";
      }
      else 
      {
        return "Invalid request!!";
      }}),catchError((error) => {    // handle error
      if (error.status == 404) {
        //Handle Response code here
      }
      return throwError(error);
      }));
  }


  changeUserStatus(userid:number,status:string):Observable<any>{     
  return this._http.patch<any>(this._apiUrl+"/admin/UpdateUserStatus/"+userid+"/"+status,{responseType:'text' as 'json'})
  .pipe(map((data: any) => {
    return data;
  }),catchError((error) => {    // handle error
      if (error.status == 404) {
        //Handle Response code here
      }
      return error;
    }));
  }
  getPatientUsers():Observable<any>
   {
    return this._http.get<any>(this._apiUrl+"/admin/GetPatientUsers",{responseType:'json' })
    .pipe(map((data:any)=>{
      return data;
    }),catchError((error) => {    // handle error
      if (error.status == 404) {
        //Handle Response code here
      }
      return throwError(error);  
  }));
   }
   getPatientUserById(id:number):Observable<any>
   {
    return this._http.get<any>(this._apiUrl+"/admin/GetPatientUser/"+id,{responseType:'text' as 'json'})
    .pipe(map((data:any)=>{

      if(data.status==200)
      {
        return data;
      }
      else if(data.status==404)
      {
        return "Patient does not exist";
      }
      else 
      {
        return "Invalid request!!";
      }

    }),catchError((error) => {    // handle error
      if (error.status == 404) {
        //Handle Response code here
      }
      return error;
  
    }));
   }
   getPatientUserByName(name:string):Observable<any>
   {
    return this._http.get<any>(this._apiUrl+"/admin/GetHospitalUsers/"+name,{responseType:'text' as 'json'})
    .pipe(map((data:any)=>{
      if(data.status==200)
      {
        return data;
      }
      else if(data.status==404)
      {
        return "No patient with this name";
      }
      else 
      {
        return "Invalid request!!";
      }
    }),catchError((error) => {    // handle error
      if (error.status == 404) {
        //Handle Response code here
      }
      return error;
    }));
   }

  changePatientStatus(userid:number,status:string):Observable<any>{
    //Change  
    return this._http.patch<any>(this._apiUrl+"/admin/UpdatePatientStatus/"+userid+"/"+status,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
    return data;
    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return error;
      }));
  }
  editPatientDetails(userid:number):Observable<any[]>{
    //Change  
    return this._http.post<any>(this._apiUrl+"/admin/EditPatientDetails/"+userid,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }
  deletePatientDetails(userid:number):Observable<any[]>{
    //Change  
    return this._http.post<any>(this._apiUrl+"/admin/DeletePatientDetails"+"/"+userid,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  updateHospitalUser(Obj:any):Observable<any>{

    //Change  

    return this._http.post<any>(this._apiUrl+'/admin/UpdateHospitalUser/'+Obj.id,Obj,{responseType:'text' as 'json'})

    .pipe(map((data: any) => {

      return data;

    }),catchError((error) => {    // handle error      

        return error;

      })

    );

  }

  











}
