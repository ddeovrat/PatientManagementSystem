import { Injectable } from '@angular/core';
import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class CustomHttpInterceptorService implements HttpInterceptor{

  constructor() { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const authToken = sessionStorage.getItem("token");
    let updatedReq:HttpRequest<any>=req.clone({
      setHeaders: {
        Authorization: `Bearer ${authToken}`
      }
    });

    return next.handle(updatedReq).pipe(
      retry(2),
      catchError((error:HttpErrorResponse)=>{
        console.log(`Error Message from Interceptor: ${req.url}, StatusCode: ${error.status}`);
        if(error.status==404)
          console.log("The requested resource could not be found");
        else
          console.log(error.message);
        return throwError(()=>new Error(error.message));
      }));
  }
}
