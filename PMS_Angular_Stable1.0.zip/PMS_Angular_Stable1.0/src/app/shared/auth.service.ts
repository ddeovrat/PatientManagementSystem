import { Injectable } from '@angular/core';
import {AngularFireAuth} from '@angular/fire/compat/auth'
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PatientLoginRegisterService } from './patient-login-register.service';



@Injectable({
  providedIn: 'root'
})
export class AuthService {

  userId:any;
  token:string="";
  loginCounter:number=0;
  constructor(private _fireauth:AngularFireAuth,private _router:Router, private _toastr:ToastrService, private _registerPatientService:PatientLoginRegisterService) { }
  
  login(emailProvided:string,passwordProvided:string){
    if(passwordProvided!="Default123")
    {
      this._registerPatientService.isLocked(emailProvided).subscribe((lockCheck:any)=>{
        if(lockCheck.value=="0"){
          if(this.loginCounter<3){
            this._fireauth.signInWithEmailAndPassword(emailProvided,passwordProvided).then(res=>{
              this.removeToken();
              this._registerPatientService.login(emailProvided,passwordProvided).subscribe((data:any)=>{ 
                this.loginCounter=0;     
                if(res.user?.emailVerified == true){
                  localStorage.setItem('token',data.token); 
                  sessionStorage.setItem('token',data.token); 
                  sessionStorage.setItem('firstName',data.firstName);
                  sessionStorage.setItem('lastName',data.lastName);
                  sessionStorage.setItem('roleId',data.roleId);
                  sessionStorage.setItem('id',data.id);
                  //this._toastr.success('Login Successfull');

                  //manish changes start
                //   if(data.roleId=="2" || data.roleId =="3" || data.roleId=="4")                
                //     this._router.navigate(['/inbox']);
                //   else if(data.roleId=="1")
                //     this._router.navigate(['/admin']);                         
                // }
                this.userId=sessionStorage.getItem("id");
                
                this._registerPatientService.getUserDetails(this.userId).subscribe((data:any)=>
                {
                  
                  
                  if(data.gender == null && data.roleId == "4")
                  {
                    sessionStorage.setItem('userdetail','0');
                    this._router.navigate(['/Patient']);

                    this._toastr.success('Login Successfull');

                  }
                  else if(data.gender !== null && data.roleId == "4")
                  {
                    
                    sessionStorage.setItem('userdetail','1');
                    this._router.navigate(['/inbox']);
                    this._toastr.success('Login Successfull');
                    
                  }

                  else if (data.roleId=="1")
                  {
                    this._router.navigate(['/admin']); 
                    this._toastr.success('Login Successfull');
                  }

                  else
                  {
                    this._router.navigate(['/inbox']);
                    this._toastr.success('Login Successfull');
                  }
                      

                });
              }



                //manish changes end
                else{
                  this._toastr.warning('Unverified User');
                  this._router.navigate(['/verify-email']);
                }
              }, err => {
                this.loginCounter += 1;
                if(this.loginCounter>=3){
                  this.lock(emailProvided);
                }
                else{
                  this.loginFailed();
                }
              });          
            },err=>{
              this.loginCounter += 1;
                if(this.loginCounter>=3){
                  this.lock(emailProvided);
                }
                else{
                  this.loginFailed();
                }
            });
          }
          else{
            this.accountLocked();
          }
        }
        else if(lockCheck.value=="1"){
          this.accountLocked();
        }
      },err=>{
        this._toastr.error('Something went wrong.. Contact Admin');
        this._router.navigate(['/login']);
      });
    }
    else
    {
      this._toastr.error('Change your default provided password');
      this._router.navigate(['/reset-password']);
    }
  }


  removeToken()
  {
    localStorage.removeItem('token');
    sessionStorage.removeItem('token');
    sessionStorage.removeItem('firstName');
    sessionStorage.removeItem('lastName');
    sessionStorage.removeItem('roleId');
    sessionStorage.removeItem('id');
  }

  loginFailed()
  {
    this._toastr.error('Login Failed');
    this._router.navigate(['/login']); 
  }

  accountLocked()
  {
    this._toastr.error('Account locked. Contact Admin');
    this._router.navigate(['/login']);
  }

  lock(emailProvided:string){
    this._registerPatientService.lockUser(emailProvided).subscribe((data:any)=>{
      this._toastr.error('Account locked. Contact Admin');
      this._router.navigate(['/login']);
    },err=>{
      this._toastr.warning('Failed to lock user');
      this._router.navigate(['/login']);
    });
  }

  //register method
  register(data:FormGroup){
    this._fireauth.createUserWithEmailAndPassword(data.value.Email,data.value.Password).then(res=>{
      this._registerPatientService.addPatient(data.value).subscribe((data:any)=>{
        this._toastr.success('Registration Successfull');
        this.sendEmailForVerification(res.user);
      }, err => {
        res.user?.delete();
        this._toastr.error('Registration Failed');
        this._router.navigate(['/register-patient']);
      }); 
    },err=>{
      this._toastr.error('Registration Failed');
      this._router.navigate(['/register-patient']);
    })
  }

  // //logout method
  logout(){
    this._fireauth.signOut().then(()=>{
      this.removeToken();
      this._router.navigate(['/login']);
    },err=>{
      alert(err.message);
    })
  }

  forgotPassword(email:string,password:string){
    this._registerPatientService.ForgotPassword(email,password).subscribe((data:any)=> {
      this._fireauth.sendPasswordResetEmail(email).then(()=>{
        this._toastr.success('Verification link sent successfully');
        this._router.navigate(['verify-email']);
        },err=>{
          this._toastr.error('Something went wrong');
      });
    },err=>{
      this._toastr.error('Failed to change password');
      this._router.navigate(['/forgot-password']);
    });
  }

  //Email Verification
  sendEmailForVerification(user:any){
    user.sendEmailVerification().then((res:any)=>{
      this._router.navigate(['/verify-email']);
    },(err:any)=>{
      alert('Something went wrong. Not able to send mail to your email.')
    });
  }

  resetPassword(email:string,oldPassword:string,newPassword:string){
    this._fireauth.signInWithEmailAndPassword(email,oldPassword).then(res=>{
      this._registerPatientService.ResetPassword(email,oldPassword,newPassword).subscribe((data:any)=> {
        res.user?.updatePassword(newPassword);
        this._toastr.success('Password updated successfully');
        this.logout();
      },err=>{
        res.user?.updatePassword(oldPassword);
        this._toastr.error('Failed to update password');
        this._router.navigate(['/reset-password']);
      }); 
    }, err => {
      this._toastr.error('Failed to update password');
      this._router.navigate(['/reset-password']);
    }); 
  }

  isloggedIn(){
    return sessionStorage.getItem("token")==localStorage.getItem("token") && sessionStorage.getItem("token")!=null ;
  }
}
