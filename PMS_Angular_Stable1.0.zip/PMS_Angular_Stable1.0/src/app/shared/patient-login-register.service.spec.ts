import { TestBed } from '@angular/core/testing';

import { PatientLoginRegisterService } from './patient-login-register.service';

describe('PatientLoginRegisterService', () => {
  let service: PatientLoginRegisterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PatientLoginRegisterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
