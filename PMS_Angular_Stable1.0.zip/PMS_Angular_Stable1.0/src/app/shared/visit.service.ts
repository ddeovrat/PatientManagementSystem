import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable,catchError, map, throwError, forkJoin } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class VisitService {

  private readonly _apiUrl = "https://localhost:44378/gateway";

  constructor(private _http:HttpClient, private _toastr:ToastrService) { }

  GetDiagnosisList():Observable<any>
  {       
   return this._http.get<any>(this._apiUrl+"/PatientVisit/GetDiagnosisList",{responseType:'json' })
   .pipe(map((data:any)=>{
   
     return data;
   }),catchError((error) => {    // handle error
     if (error.status == 404) {       
     }
     return error;
 })
   );
  }

  GetProceduresList():Observable<any>
  {       
   return this._http.get<any>(this._apiUrl+"/PatientVisit/GetProceduresList",{responseType:'json' })
   .pipe(map((data:any)=>{   
     return data;
   }),catchError((error) => {    // handle error
     if (error.status == 404) {       
     }
     return error;
 })
   );
  }

  GetMedicationsList():Observable<any>
  {       
   return this._http.get<any>(this._apiUrl+"/PatientVisit/GetMedicationsList",{responseType:'json' })
   .pipe(map((data:any)=>{   
     return data;
   }),catchError((error) => {    // handle error
     if (error.status == 404) {       
     }
     return error;
 })
   );
  }
  GetVitalSignsdata(AppId:number):Observable<any>
  {       
   return this._http.get<any>(this._apiUrl+"/PatientVisit/GetVitalSignData/"+AppId,{responseType:'json' })
   .pipe(map((data:any)=>{   
     return data;
   }),catchError((error) => {  
    debugger;  // handle error
     if (error.status == 404) {       
     }
     return error;
 })
   );
  }

  AddVitalsignData(dt:any){
    debugger;
    return this._http.post<any>(this._apiUrl+'/PatientVisit/AddVitalSignData',dt,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;    
    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }
  // AddVisitDetails(dt1:any, dt2: any, dt3:any): Observable<any[]>{
  //   let VisitId:number=0;
  //   let DiagnosisVisitId:number=0;
  //   let resp1= this._http.post<any>(this._apiUrl+'/PatientVisit/AddVitalSignData',dt1,{responseType:'text' as 'json'})
  //   .pipe(map((data1: any) => {
  //     VisitId= data1;      
  //     dt2.VisitId=data1;
  //     dt3.VisitId=data1;
  //   }),catchError((error) => {    // handle error
       
  //       return error;
  //     })
  //   );  
  //  let resp2 =this._http.post<any>(this._apiUrl+'/PatientVisit/AddDiagnosisVisitData',dt2,{responseType:'text' as 'json'})
  //     .pipe(map((data2: any) => {
  //       data2;
  //     }),catchError((error) => {    // handle error
         
  //         return error;
  //       })
  //     ); 

  //     let resp3= this._http.post<any>(this._apiUrl+'/PatientVisit/AddProcedureVisitData',dt3,{responseType:'text' as 'json'})
  //     .pipe(map((data3: any) => {
  //        data3;    
  //     }),catchError((error) => {    // handle error               
  //         return error;
  //       })
  //     );
  //     debugger;
  //   return forkJoin([resp1, resp2, resp3])
  // }
  AddDiagnosisData(dt2:any){
    debugger;
    return this._http.post<any>(this._apiUrl+'/PatientVisit/AddDiagnosisVisitData',dt2,{responseType:'text' as 'json'})
      .pipe(map((data2: any) => {
       return data2;
      }),catchError((error) => {    // handle error
         
          return error;
        })
      );
  }
  AddProcedureData(dt3:any){
    debugger;
    return this._http.post<any>(this._apiUrl+'/PatientVisit/AddProcedureVisitData',dt3,{responseType:'text' as 'json'})
      .pipe(map((data3: any) => {
        return data3;    
      }),catchError((error) => {    // handle error               
          return error;
        })
      );
  }

  AddMedicationData(dt4:any){
    debugger;
    return this._http.post<any>(this._apiUrl+'/PatientVisit/AddMedicationVisitData',dt4,{responseType:'text' as 'json'})
      .pipe(map((data3: any) => {
        return data3;    
      }),catchError((error) => {    // handle error               
          return error;
        })
      );
  }
  
  UpdateVitalsignData(dt:any){
    debugger;
    return this._http.put<any>(this._apiUrl+'/PatientVisit/UpdateVitalSignData',dt,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;    
    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }
  UpdateDiagnosisVisitData(dt:any){
    debugger;
    return this._http.put<any>(this._apiUrl+'/PatientVisit/UpdateDiagnosisVisitData',dt,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;    
    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }
  UpdateProcedureVisitData(dt:any){
    debugger;
    return this._http.put<any>(this._apiUrl+'/PatientVisit/UpdateProcedureVisitData',dt,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;    
    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }
  UpdateMedicationVisitData(dt:any){
    debugger;
    return this._http.put<any>(this._apiUrl+'/PatientVisit/UpdateMedicationVisitData',dt,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;    
    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }

  UpdateAppointmentStatus( AppId:number,AppStatus:string){
    debugger;
    return this._http.put<any>(this._apiUrl+'/PatientVisit/UpdateAppointmentStatus/'+AppId+'/'+AppStatus,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;    
    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }
}
