import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SchedulerService {

  baseUrl:string  = "https://localhost:44378/gateway/scheduler/";

  dummyUrl:string = "https://localhost:44381/api/Appointments/";

  constructor(private httpObj:HttpClient) { }

  public RoleId = sessionStorage.getItem('roleId');
  public UserId = sessionStorage.getItem('id',);


  // Read All

  public getAppointments():Observable<any[]>{
    //Change  
    return this.httpObj.get<any>(this.baseUrl+"GetAppointments",{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      //handle api 200 response code here or you wanted to manipulate to response
      if( Number(this.RoleId) == 2)
      {
       return  JSON.parse(data).filter((item: { userId: number; }) => item.userId == Number(this.UserId) );
      }
      else if(Number(this.RoleId) == 4)
      {
      return  JSON.parse(data).filter((item: { patientId: number; }) => item.patientId == Number(this.UserId) );
      }
      else{
        return JSON.parse(data);
      }
    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  // Create
  public addAppointment(SchedulerObj:any):Observable<any[]>{
    //Change  
    return this.httpObj.post<any>(this.baseUrl+"AddAppointment",SchedulerObj,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return JSON.parse(data);
    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  // Update
  public updateAppointment(SchedulerObj:any):Observable<any[]>
  {
    return this.httpObj.put<any>(this.baseUrl+"UpdateAppointment",SchedulerObj,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return JSON.parse(data);

    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }


  // Delete
  public deleteAppointment(SchedulerObj:any):Observable<any[]>
  {
    debugger;
    return this.httpObj.delete<any>(this.baseUrl+"DeleteAppointment/"+Number(SchedulerObj),{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return JSON.parse(data);
    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  //GetPhysicians
   public getPhysicians():Observable<any[]>
   {
     return this.httpObj.get<any[]>(this.baseUrl+"GetPhysicians").pipe(
       map(res => {
         return  res;
     })
     );
   }

   //GetPatients
   public getPatients():Observable<any[]>
   {
     return this.httpObj.get<any[]>(this.baseUrl+"GetPatients").pipe(
       map(res => {
         return  res;
     })
     );
   }
}
