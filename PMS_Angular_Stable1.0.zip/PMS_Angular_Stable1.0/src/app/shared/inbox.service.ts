import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable,catchError, map, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class InboxService {

  private readonly _apiUrl = "https://localhost:44378/gateway";

  constructor(private _http:HttpClient, private _toastr:ToastrService) {
   }

  public getAppointments():Observable<any[]>
  {
    return this._http.get<any>(this._apiUrl+"/inbox/GetUpcomingAppointments",{responseType:'text' as 'json'}).pipe(map((data: any) => {
      if( Number(sessionStorage.getItem("roleId")) == 2)
      {
       return  JSON.parse(data).filter((item: { userId: number;}) => item.userId == Number(sessionStorage.getItem("id")));
      }
      else
       return JSON.parse(data);

       }),catchError((error) => {    

        if (error.status == 404) {
        }

        return throwError(error);
      })
    );
  }

  public getAppointmentsForPatients():Observable<any[]>{
    return this._http.get<any>(this._apiUrl+"/inbox/GetUpcomingAppointmentsForPatient",{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    return   JSON.parse(data).filter((item: { status: string; patientId: number; }) => item.patientId == Number(sessionStorage.getItem("id")));

}),catchError((error) => {   
    if (error.status == 404) {
    }
    return throwError(error);
  })
);
 }

public getDeclinedAppointments():Observable<any[]>{
    return this._http.get<any>(this._apiUrl+"/inbox/GetUpcomingAppointmentsForPatient",{responseType:'text' as 'json'})
.pipe(map((data: any) => {

  return  JSON.parse(data).filter((item: { status: string; patientId: number; }) => item.status == "Rejected" && item.patientId == Number(sessionStorage.getItem("id")));
}),catchError((error) => {   

    if (error.status == 404) {
    }
     return throwError(error);
  })
);
  }

acceptAppointment(appointmentId:number):Observable<any>
  {
    return this._http.patch<any>(this._apiUrl+"/inbox/AcceptAppointment/"+appointmentId,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;
    }),catchError((error) => {   
       
        return error;
      })
    );
  }

  rejectAppointment(appointmentId:number):Observable<any>
  {
    return this._http.patch<any>(this._apiUrl+"/inbox/RejectAppointment/"+appointmentId,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;
    }),catchError((error) => {  
       
        return error;
      })
    );
  }

  deleteappointment(appointmentId:number):Observable<any>
  {
    return this._http.patch<any>(this._apiUrl+"/inbox/DeleteAppointment/"+appointmentId,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;
    }),catchError((error) => {    
       
        return error;
      })
    );

  }

  sendNote(val:any):Observable<any>{
    var noteObj= {ResponseAgainst:val.value.ResponseAgainst,SenderId:Number(sessionStorage.getItem("id")), ReceiverId:Number(val.value.Receiver), 
      UrgencyLevel: val.value.Urgency, MessageSent: val.value.Message,SenderDesignation:Number(sessionStorage.getItem("roleId"))}
    return this._http.post<any>(this._apiUrl+'/inbox/SendNote',noteObj,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return data;
    }),catchError((error) => {    // handle error       
        return error;
      })
    );
    
  }

  getHospitalUsers():Observable<any[]>
  {
    return this._http.get<any>(this._apiUrl+"/inbox/GetHospitalUsers",{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return JSON.parse(data).filter((item: {id: number; }) =>item.id != Number(sessionStorage.getItem("id")));
    }),catchError((error) => {   
    
        if (error.status == 404) {
        }
         return throwError(error);
      })
    );
  }
  getHospitalUser(messageId:any,senderId:any):Observable<any[]>
  {
    return this._http.get<any>(this._apiUrl+"/inbox/GetHospitalUsers",{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return  JSON.parse(data).filter((item: {id: number; }) =>item.id == senderId);
    }),catchError((error) => {   
    
        if (error.status == 404) {
        }
         return throwError(error);
      })
    );
  }


  getDesignation(id:any):Observable<any>
  {
    return this._http.get<any>(this._apiUrl+"/inbox/GetDesignation/"+id,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
      return  data;
    }),catchError((error) => {   
    
        if (error.status == 404) {
        }
         return throwError(error);
      })
    );
  }

  getSentNotes(id:any):Observable<any[]>
  {
    return this._http.get<any[]>(this._apiUrl+"/inbox/GetSentNotes/"+id,{responseType:'json'})
    .pipe(map((data: any) => {
    
      return  data;
    }),catchError((error) => {   
    
        if (error.status == 404) {
        }
         return throwError(error);
      })
    );
  }

  getReceivedNotes(id:any):Observable<any[]>
  {
    return this._http.get<any[]>(this._apiUrl+"/inbox/GetReceivedNotes/"+id,{responseType:'json'})
    .pipe(map((data: any) => {
    
      return  data;
    }),catchError((error) => {   
    
        if (error.status == 404) {
        }
         return throwError(error);
      })
    );
  }

}
