import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable,catchError, map, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientLoginRegisterService {
  private readonly _apiUrl = "https://localhost:44378/gateway";

  constructor(private _http:HttpClient) { }
  
  addPatient(val:any):Observable<any[]>{
    //Change  
    return this._http.post<any>(this._apiUrl+'/user/RegisterUser',val,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  login(email:string,password:string):Observable<any[]>{
    return this._http.post<any>(this._apiUrl+"/auth/UserLogin/"+email+"/"+password,{responseType: 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {    // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  lockUser(email:string):Observable<any[]>{
    return this._http.post<any>(this._apiUrl+"/auth/LockUser/"+email,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {  
     // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  isLocked(email:string):Observable<any[]>{
    return this._http.get<any>(this._apiUrl+"/auth/IsLock/"+email,{responseType:'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {  
     // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  public ResetPassword(email:string,oldPassword:string,newPassword:string):Observable<any[]>{
    return this._http.put<any>(this._apiUrl+"/user/UpdatePassword/"+email+"/"+oldPassword+"/"+newPassword,{responseType:'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {  
     // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  public ForgotPassword(email:string,password:string):Observable<any[]>{    
    return this._http.put<any>(this._apiUrl+"/user/ForgotPassword/"+email+"/"+password,{responseType:'json'})
    .pipe(map((data: any) => {
    //handle api 200 response code here or you wanted to manipulate to response
      return data;

    }),catchError((error) => {  
     // handle error
        if (error.status == 404) {
          //Handle Response code here
        }
        return throwError(error);
      })
    );
  }

  getUserDetails(id:number):Observable<any>
  {
   return this._http.get<any>(this._apiUrl+"/user/GetUserDetails/"+id,{responseType:'json' })
   .pipe(map((data:any)=>{
   
     return data;

    }),catchError((error) => {    // handle error
     if (error.status == 404) {
       //Handle Response code here
     }
     return error;
    })

   );
  }

}
