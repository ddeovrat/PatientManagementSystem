import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { Observable,catchError, map, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientService {

  private readonly _apiUrl = "https://localhost:44378/gateway";
  constructor(private _http:HttpClient, private _toastr:ToastrService) { }

  addPatientDemographics(id:number, val:any):Observable<any>{
    //Change  
    

    var demodetails= {Gender:val.value.gender, Race:val.value.race, Ethnicity: val.value.ethinicity, 
      Address: val.value.address, Language: val.value.languages }

      

      console.log(demodetails);
    return this._http.post<any>(this._apiUrl+"/patient/AddPatientDemographics/"+id,demodetails,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {

      return data;

    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }



  addPatientEmergency(id:number, val:any):Observable<any>{
    //Change  
    debugger;
    var emergencydetail1={EFirstName:val.value.emergencyContact.EfirstName, ELastName:val.value.emergencyContact.ElastName, ERelationship: val.value.emergencyContact.relationship, 
      EEmailAddress: val.value.emergencyContact.Eemail, EContact: val.value.emergencyContact.Econtact, EAddress:val.value.emergencyContact.Eaddress, ENeedAccessToPortal:1}
    debugger;
  
      var emergencydetail={EFirstName:val.value.EfirstName, ELastName:val.value.ElastName, ERelationship: val.value.relationship, 
        EEmailAddress: val.value.Eemail, EContact: val.value.Econtact, EAddress:val.value.Eaddress, ENeedAccessToPortal:val.value.accessPortal}
      debugger;

      console.log(emergencydetail);
      console.log(emergencydetail1);

    return this._http.post<any>(this._apiUrl+"/patient/AddPatientEmergencyInfo/"+id,emergencydetail1,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {

      return data;

    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }

  getAllergyType():Observable<any>
  {
  
   
   return this._http.get<any>(this._apiUrl+"/patient/GetAllergyTypes",{responseType:'json' })
   .pipe(map((data:any)=>{
   
     return data;

   }),catchError((error) => {    // handle error
     if (error.status == 404) {
       //Handle Response code here
     }
     return error;
 
 })

   );
  }

  getAllergyName(type:string):Observable<any>
  {
  
   
   return this._http.get<any>(this._apiUrl+"/patient/GetAllergiesByType/"+type,{responseType:'json' })
   .pipe(map((data:any)=>{
   
     return data;

   }),catchError((error) => {    // handle error
     if (error.status == 404) {
       //Handle Response code here
     }
     return error;
 
 })

   );
  }

  addAllergies(id:number, val:any, allergyText:string):Observable<any>
  {

    var allergydetail={ AllergyId:val.value.allergyDetails.allergyName, AllergyName:allergyText, AllergyType: val.value.allergyDetails.allergyType, 
    AllergyClinicalInformation: val.value.allergyDetails.clinicalInformation, AllergyDescription: val.value.allergyDetails.decription, IsAllergyFatal:1}
    debugger;
  
      console.log(allergydetail);

    return this._http.post<any>(this._apiUrl+"/patient/PatientAllergy/"+id,allergydetail,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {

      return data;

    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }


  addFamilyDisease(id:number, val:any):Observable<any>
  {
    var familyDiseasedetail={ DiseaseDecription: val.value.DiseaseDetails.Information }
    
    
    debugger;
  
      console.log(familyDiseasedetail);

    return this._http.post<any>(this._apiUrl+"/patient/AddPatientDiseaseHistory/"+id,familyDiseasedetail,{responseType:'text' as 'json'})
    .pipe(map((data: any) => {

      return data;

    }),catchError((error) => {    // handle error
       
        return error;
      })
    );
  }


  getPatientDetails(id:number):Observable<any>
  {
  
   
   return this._http.get<any>(this._apiUrl+"/patient/GetDetails/"+id,{responseType:'json' })
   .pipe(map((data:any)=>{
   
     return data;

   }),catchError((error) => {    // handle error
     if (error.status == 404) {
       //Handle Response code here
     }
     return error;
 
 })

   );
  }

  getUserData(id:number):Observable<any>
  {
  
   
   return this._http.get<any>(this._apiUrl+"/patient/GetUserData/"+id,{responseType:'json' })
   .pipe(map((data:any)=>{
   
     return data;

   }),catchError((error) => {    // handle error
     if (error.status == 404) {
       //Handle Response code here
     }
     return error;
 
 })

   );
  }


}
