import { Component, OnInit } from '@angular/core';
import { AuthService } from '../shared/auth.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: [
    // '../../assets/css/bootstrap.min.css',
        // '../../assets/css/font-awesome.min.css',
        // '../../assets/css/style.css'
  ],
  
  
})
export class LandingComponent implements OnInit {

  constructor(private _auth:AuthService) { }

  ngOnInit(): void {
  }

  logout(){
    this._auth.logout();
  }

}
