import { NgModule } from '@angular/core';
import { FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
// import { LoginComponent } from './login/login.component';
// import { RegisterComponent } from './register-module/register.component';
// import { LandingComponent } from './landing/landing.component';
import { AngularFireModule } from '@angular/fire/compat';
import { environment } from 'src/environments/environment';
import { ToastrModule } from 'ngx-toastr';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { VerifyEmailComponent } from './verify-email/verify-email.component';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { PatientLoginRegisterService } from './shared/patient-login-register.service';
import { AuthService } from './shared/auth.service';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { LayoutModule } from './layout/layout.module';
import { CustomHttpInterceptorService } from './shared/custom-http-interceptor.service';

@NgModule({
  declarations: [
    AppComponent,
    // LoginComponent,
    // RegisterComponent,
    // LandingComponent,
    ForgotPasswordComponent,
    RegisterPatientComponent,
    VerifyEmailComponent,
    ResetPasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp(environment.firebase),
    FormsModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([]),
    ToastrModule.forRoot(),
    HttpClientModule,
    LayoutModule
  ],
  providers: [
    FormsModule,PatientLoginRegisterService,AuthService,
    {provide: HTTP_INTERCEPTORS, useClass: CustomHttpInterceptorService, multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
