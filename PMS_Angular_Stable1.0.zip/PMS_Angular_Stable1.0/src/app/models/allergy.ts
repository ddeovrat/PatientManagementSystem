export default class Allergy{
    id: string = "";
    type: string ="";
    name: string ="";
    source: string ="";
    isoforms: string ="";
    allerginicity: string="";


}