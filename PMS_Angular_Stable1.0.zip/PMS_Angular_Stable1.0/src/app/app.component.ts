import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [
    './app.component.css',
    '../assets/css/bootstrap.min.css',
        '../assets/css/font-awesome.min.css',
        '../assets/css/style.css']
})
export class AppComponent {
  title = 'PMS_Frontend';
}
