import { NgModule } from '@angular/core';
import { LaoyoutRoutingModule } from './layout-routing.module';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule } from '@angular/router';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainlayoutComponent } from './mainlayout/mainlayout.component';
import { AdminModule } from '../admin/admin.module';
import { PatientModule } from '../patient-module/patient.module';



@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    MainlayoutComponent
  ],
  imports: [
    CommonModule,
    LaoyoutRoutingModule,
    AdminModule,
    PatientModule,
    RouterModule.forChild([])
  ],
  exports:[
    HeaderComponent,
    FooterComponent,
    SidebarComponent
  ]
})
export class LayoutModule { }
