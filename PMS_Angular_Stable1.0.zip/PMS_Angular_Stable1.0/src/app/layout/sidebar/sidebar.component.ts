import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: [  
  './sidebar.component.css'
]
})
export class SidebarComponent implements OnInit {

  roleId:any;
  userdetail:any;
  constructor() { }

  ngOnInit(): void {
    this.roleId=sessionStorage.getItem("roleId");
    this.userdetail=sessionStorage.getItem("userdetail");
  }

}
