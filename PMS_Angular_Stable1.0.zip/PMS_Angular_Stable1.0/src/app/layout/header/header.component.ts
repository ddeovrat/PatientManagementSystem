import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/shared/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: [  
  './header.component.css'
  ]
})
export class HeaderComponent implements OnInit {

  titleName:any="";
  constructor(private _auth:AuthService) { }  
  ngOnInit(): void {
    this.titleName = sessionStorage.getItem("firstName")
  }
  
  logout(){
    this._auth.logout();
  }

}
