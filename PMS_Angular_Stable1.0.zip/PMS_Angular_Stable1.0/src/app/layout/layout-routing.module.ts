import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainlayoutComponent } from './mainlayout/mainlayout.component';

const routes: Routes = [
    {
    
    path:'',
    component:MainlayoutComponent,
    children:[
        {
            path:'',loadChildren:()=> import('../patient-module/patient.module').then(m=>m.PatientModule)
        },
        {
            path:'admin',loadChildren:()=> import('../admin/admin.module').then(m=>m.AdminModule)
        },
        {
            path:'scheduler',loadChildren:()=> import('../scheduler/scheduler.module').then(m=>m.SchedulerModule)
        },
        {
            path:'inbox',loadChildren:()=> import('../inbox/inbox.module').then(m=>m.InboxModule)
        },
        {
            path:'visit',loadChildren:()=> import('../visit-module/visit.module').then(m=>m.VisitModule)
        }
        
    ]
},
// {
    
//     path:'Patient',
//     component:MainlayoutComponent,
//     children:[
//         {
//             path:'',loadChildren:()=> import('../patient-module/patient.module').then(m=>m.PatientModule)
//         }
//     ]
// }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class LaoyoutRoutingModule { }