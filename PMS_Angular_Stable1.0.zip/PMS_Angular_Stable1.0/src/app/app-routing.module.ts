import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { LandingComponent } from './landing/landing.component';
// import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { RegisterPatientComponent } from './register-patient/register-patient.component';
import { VerifyEmailComponent } from './verify-email/verify-email.component';
import { RoleGuard } from './shared/role.guard';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

const routes: Routes = [
  {path:'',redirectTo:'login',pathMatch:'full'},
  {path:'login',loadChildren: ()=> import('./login-module/login.module').then(m=> m.LoginModule)},
{path:'Admin',loadChildren: ()=> import('./layout/layout.module').then(m=> m.LayoutModule),canActivate:[RoleGuard]},
{path:'Patient',loadChildren: ()=> import('./layout/layout.module').then(m=> m.LayoutModule),canActivate:[RoleGuard]},
{path:'Visit',loadChildren: ()=> import('./layout/layout.module').then(m=> m.LayoutModule)},
  // {path:'landing',component:LandingComponent,canActivate:[RoleGuard]},
  // {path:'landing',component:LandingComponent},
  {path:'forgot-password',component:ForgotPasswordComponent},
  {path:'register-patient',component:RegisterPatientComponent},
  {path:'verify-email',component:VerifyEmailComponent},
  {path:'reset-password',component:ResetPasswordComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
